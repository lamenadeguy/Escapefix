package models

import (
	"time"

	"3ch/backend/database"
)

type MediaApproval struct {
	ID                  int    `gorm:"column:id"`
	Board               string `gorm:"column:board"`
	Num                 int    `gorm:"column:num"`
	FileIndex           int    `gorm:"column:file_index"`
	MD5                 string `gorm:"column:md5"`
	Status              int    `gorm:"column:status"`
	PublicPath          string `gorm:"column:public_path"`
	PublicThumbnail     string `gorm:"column:public_thumbnail"`
	RealPath            string `gorm:"column:real_path"`
	RealThumbnail       string `gorm:"column:real_thumbnail"`
	OriginalFullName    string `gorm:"column:original_fullname"`
	OriginalDisplayName string `gorm:"column:original_displayname"`
	ApprovedBy          string `gorm:"column:approved_by"`
	CreatedAt           int64  `gorm:"column:created_at"`
}

func (MediaApproval) TableName() string {
	return "media_approvals"
}

func (m *MediaApproval) Create() error {
	m.CreatedAt = time.Now().Unix()
	err := database.MySQL.Create(&m).Error
	return err
}

func (m *MediaApproval) GetById(id int) error {
	return database.MySQL.First(&m, "id = ?", id).Error
}

func (m *MediaApproval) Update() error {
	return database.MySQL.Save(&m).Error
}

type MediaApprovals []MediaApproval

func GetPendingMediaApprovals() MediaApprovals {
	var rows MediaApprovals
	database.MySQL.Where("status = 0").Order("id desc").Limit(300).Find(&rows)
	return rows
}

func GetProcessedMediaApprovals() MediaApprovals {
	var rows MediaApprovals
	database.MySQL.Where("status != 0").Order("id desc").Limit(200).Find(&rows)
	return rows
}
