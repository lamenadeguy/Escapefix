package api

import (
	"os"
	"strconv"
	"net/http"
	"text/template"
	"encoding/json"
	"path/filepath"

	"github.com/gorilla/mux"
	"github.com/gorilla/context"

	"3ch/backend/models"
	"3ch/backend/structs"
	"3ch/backend/i18n"
)

func ModerMediaList(w http.ResponseWriter, r *http.Request) {
	var moderPage structs.ModerPage
	moderPage.CurrentSection = "media"
	moderPage.Lang, _ = i18n.GetTranslations(os.Getenv("LANGUAGE"))
	moderPage.LangJson, _ = i18n.GetTranslationsJsonByPrefix(os.Getenv("LANGUAGE"), "moderation_")

	currentModer := context.Get(r, "currentModer").(models.Moder)
	moderPage.CurrentModer = currentModer

	for _, row := range models.GetPendingMediaApprovals() {
		moderPage.PendingMedia = append(moderPage.PendingMedia, structs.PendingMediaItem{
			ApprovalID:       row.ID,
			Board:            row.Board,
			Num:              row.Num,
			MD5:              row.MD5,
			Path:             row.PublicPath,
			Thumbnail:        row.PublicThumbnail,
			OriginalFullName: row.OriginalFullName,
			Approved:         row.Status,
		})
	}

	for _, row := range models.GetProcessedMediaApprovals() {
		moderPage.PendingMedia = append(moderPage.PendingMedia, structs.PendingMediaItem{
			ApprovalID:       row.ID,
			Board:            row.Board,
			Num:              row.Num,
			MD5:              row.MD5,
			Path:             row.PublicPath,
			Thumbnail:        row.PublicThumbnail,
			OriginalFullName: row.OriginalFullName,
			Approved:         row.Status,
			ApprovedBy:       row.ApprovedBy,
		})
	}

	ex, _ := os.Executable()
	exPath := filepath.Dir(ex)

	w.Header().Set("Content-Type", "text/html")

	tpls := make(map[string]*template.Template)
	tpls["top"] = template.Must(template.ParseFiles(exPath + "/templates/moder/top.html"))
	tpls["main"] = template.Must(template.ParseFiles(exPath + "/templates/moder/media.html"))
	tpls["bottom"] = template.Must(template.ParseFiles(exPath + "/templates/moder/bottom.html"))

	tpls["top"].ExecuteTemplate(w, "base", moderPage)
	tpls["main"].ExecuteTemplate(w, "base", moderPage)
	tpls["bottom"].ExecuteTemplate(w, "base", moderPage)
}

func ModerMediaPreview(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	approvalId, _ := strconv.Atoi(vars["id"])

	var approval models.MediaApproval
	err := approval.GetById(approvalId)

	if(err != nil || approval.Status != 0) {
		http.NotFound(w, r)
		return
	}

	http.ServeFile(w, r, approval.RealThumbnail)
}

func ModerMediaAction(w http.ResponseWriter, r *http.Request) {
	currentModer := context.Get(r, "currentModer").(models.Moder)

	r.ParseForm()

	approvalId, _ := strconv.Atoi(r.FormValue("id"))
	action := r.FormValue("action")

	var approval models.MediaApproval
	err := approval.GetById(approvalId)

	if(err != nil || approval.Status != 0) {
		http.Redirect(w, r, "/moder/media", http.StatusSeeOther)
		return
	}

	os.Remove(os.Getenv("GENERATED_CACHE_DIRECTORY") + approval.PublicPath)
	os.Remove(os.Getenv("GENERATED_CACHE_DIRECTORY") + approval.PublicThumbnail)

	var newFullName string
	var newDisplayName string

	if(action == "approve") {
		os.Symlink(approval.RealPath, os.Getenv("GENERATED_CACHE_DIRECTORY")+approval.PublicPath)
		os.Symlink(approval.RealThumbnail, os.Getenv("GENERATED_CACHE_DIRECTORY")+approval.PublicThumbnail)

		newFullName = approval.OriginalFullName
		newDisplayName = approval.OriginalDisplayName
		approval.Status = 1
	} else if(action == "reject") {
		os.Symlink(os.Getenv("GENERATED_CACHE_DIRECTORY")+"/static/img/eliminated_placeholder.jpg", os.Getenv("GENERATED_CACHE_DIRECTORY")+approval.PublicPath)
		os.Symlink(os.Getenv("GENERATED_CACHE_DIRECTORY")+"/static/img/eliminated_placeholder.jpg", os.Getenv("GENERATED_CACHE_DIRECTORY")+approval.PublicThumbnail)

		os.Remove(approval.RealPath)
		os.Remove(approval.RealThumbnail)

		newFullName = "REDACTED BY ROSKOMNADZOR (ELIMINATED)"
		newDisplayName = "REDACTED BY ROSKOMNADZOR (ELIMINATED)"
		approval.Status = 2
	} else {
		http.Redirect(w, r, "/moder/media", http.StatusSeeOther)
		return
	}

	approval.ApprovedBy = currentModer.Login
	approval.Update()

	var post models.Post
	err = post.GetByBoardNum(approval.Board, approval.Num)

	if(err == nil) {
		var filesParsed models.Files
		json.Unmarshal([]byte(post.Files), &filesParsed)

		if(approval.FileIndex >= 0 && approval.FileIndex < len(filesParsed)) {
			f := filesParsed[approval.FileIndex]
			f.FullName = newFullName
			f.DisplayName = newDisplayName
			f.Approved = approval.Status
			filesParsed[approval.FileIndex] = f

			updatedFilesJson, _ := json.Marshal(filesParsed)
			post.Files = string(updatedFilesJson)
			post.Update()
		}
	}

	http.Redirect(w, r, "/moder/media", http.StatusSeeOther)
}
