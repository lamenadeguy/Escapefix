ALTER TABLE `boards` ADD COLUMN `owner_passcode_id` INT NOT NULL DEFAULT 0;
ALTER TABLE `boards` ADD INDEX `owner_passcode_id` (`owner_passcode_id`);
