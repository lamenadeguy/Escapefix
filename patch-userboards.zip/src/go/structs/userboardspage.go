package structs

import "3ch/backend/models"

type UserboardsPage struct {
	AuthFailed  int
	ErrorText   string
	CreateError string
	LoggedIn    bool
	Boards      models.Boards
	MaxBoards   int
}
