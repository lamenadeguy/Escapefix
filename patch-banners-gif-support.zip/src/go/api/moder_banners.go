package api

import (
	"os"
	"io"
	"image"
	"image/jpeg"
	"image/gif"
	"image/draw"
	"image/color/palette"
	_ "image/png"
	_ "golang.org/x/image/webp"
	"math"
	"strconv"
	"strings"
	"net/http"
	"text/template"
	"encoding/json"
	"path/filepath"

	"github.com/gorilla/mux"
	"github.com/gorilla/context"
	"github.com/nfnt/resize"
	"github.com/thanhpk/randstr"

	"3ch/backend/models"
	"3ch/backend/structs"
	"3ch/backend/database"
	"3ch/backend/i18n"
)

const bannerWidth = 300
const bannerHeight = 100

// Scales the image up (never down below target) so it fully covers a
// bannerWidth x bannerHeight box, then crops the centered excess -- so the
// output is *always* exactly 300x100, regardless of the source image's
// original size or aspect ratio.
func resizeBannerCover(img image.Image) image.Image {
	bounds := img.Bounds()
	srcW := bounds.Dx()
	srcH := bounds.Dy()

	if(srcW == 0 || srcH == 0) {
		return image.NewRGBA(image.Rect(0, 0, bannerWidth, bannerHeight))
	}

	scaleW := float64(bannerWidth) / float64(srcW)
	scaleH := float64(bannerHeight) / float64(srcH)

	scale := scaleW
	if(scaleH > scale) {
		scale = scaleH
	}

	newW := uint(math.Ceil(float64(srcW) * scale))
	newH := uint(math.Ceil(float64(srcH) * scale))

	if(newW < bannerWidth) {
		newW = bannerWidth
	}

	if(newH < bannerHeight) {
		newH = bannerHeight
	}

	resized := resize.Resize(newW, newH, img, resize.Lanczos3)

	offsetX := (int(newW) - bannerWidth) / 2
	offsetY := (int(newH) - bannerHeight) / 2

	canvas := image.NewRGBA(image.Rect(0, 0, bannerWidth, bannerHeight))
	draw.Draw(canvas, canvas.Bounds(), resized, image.Point{offsetX, offsetY}, draw.Src)

	return canvas
}

// Composites each raw GIF frame (which may only cover part of the canvas
// and rely on the previous frame underneath) into a full-canvas RGBA image,
// so each frame can be resized/cropped independently and correctly.
func decodeGifFrames(r io.Reader) ([]image.Image, []int, error) {
	g, err := gif.DecodeAll(r)

	if(err != nil) {
		return nil, nil, err
	}

	frames := make([]image.Image, len(g.Image))
	canvas := image.NewRGBA(image.Rect(0, 0, g.Config.Width, g.Config.Height))

	for i, frame := range g.Image {
		draw.Draw(canvas, frame.Bounds(), frame, frame.Bounds().Min, draw.Over)

		frameCopy := image.NewRGBA(canvas.Bounds())
		draw.Draw(frameCopy, frameCopy.Bounds(), canvas, image.Point{}, draw.Src)
		frames[i] = frameCopy

		if(i < len(g.Disposal) && g.Disposal[i] == gif.DisposalBackground) {
			draw.Draw(canvas, frame.Bounds(), image.Transparent, image.Point{}, draw.Src)
		}
	}

	return frames, g.Delay, nil
}

func toPaletted(img image.Image) *image.Paletted {
	paletted := image.NewPaletted(image.Rect(0, 0, bannerWidth, bannerHeight), palette.Plan9)
	draw.FloydSteinberg.Draw(paletted, paletted.Bounds(), img, image.Point{})
	return paletted
}

// Resizes/crops every frame of an animated GIF to exactly 300x100 and
// re-encodes it as an animated GIF, keeping each frame's original delay.
func writeResizedAnimatedGif(w io.Writer, r io.Reader) error {
	frames, delays, err := decodeGifFrames(r)

	if(err != nil) {
		return err
	}

	out := &gif.GIF{}

	for i, frame := range frames {
		resizedFrame := resizeBannerCover(frame)
		out.Image = append(out.Image, toPaletted(resizedFrame))

		delay := 10

		if(i < len(delays)) {
			delay = delays[i]
		}

		out.Delay = append(out.Delay, delay)
	}

	return gif.EncodeAll(w, out)
}

func ModerBannersList(w http.ResponseWriter, r *http.Request) {
	var moderPage structs.ModerPage
	moderPage.CurrentSection = "banners"
	moderPage.Lang, _ = i18n.GetTranslations(os.Getenv("LANGUAGE"))
	moderPage.LangJson, _ = i18n.GetTranslationsJsonByPrefix(os.Getenv("LANGUAGE"), "moderation_")

	currentModer := context.Get(r, "currentModer").(models.Moder)

	if(currentModer.Level < 4) {
		http.Redirect(w, r, "/moder/posts", http.StatusSeeOther)
		return
	}

	moderPage.CurrentModer = currentModer

	var boards models.Boards

	database.MySQL.Order("id asc").Find(&boards)

	moderPage.Boards = boards
	moderPage.Banners = models.GetAllBanners()

	ex, _ := os.Executable()
	exPath := filepath.Dir(ex)

	w.Header().Set("Content-Type", "text/html")

	tpls := make(map[string]*template.Template)
	tpls["top"] = template.Must(template.ParseFiles(exPath + "/templates/moder/top.html"))
	tpls["main"] = template.Must(template.ParseFiles(exPath + "/templates/moder/moders_banners.html"))
	tpls["bottom"] = template.Must(template.ParseFiles(exPath + "/templates/moder/bottom.html"))

	tpls["top"].ExecuteTemplate(w, "base", moderPage)
	tpls["main"].ExecuteTemplate(w, "base", moderPage)
	tpls["bottom"].ExecuteTemplate(w, "base", moderPage)
}

func ModerBannersUpload(w http.ResponseWriter, r *http.Request) {
	currentModer := context.Get(r, "currentModer").(models.Moder)

	if(currentModer.Level < 4) {
		http.Redirect(w, r, "/moder/posts", http.StatusSeeOther)
		return
	}

	err := r.ParseMultipartForm(20 << 20) // 20MB

	if(err != nil) {
		http.Redirect(w, r, "/moder/banners", http.StatusSeeOther)
		return
	}

	file, handler, err := r.FormFile("banner")

	if(err != nil) {
		http.Redirect(w, r, "/moder/banners", http.StatusSeeOther)
		return
	}

	defer file.Close()

	isGif := strings.ToLower(filepath.Ext(handler.Filename)) == ".gif"

	bannersDir := os.Getenv("GENERATED_CACHE_DIRECTORY") + "/static/banners"

	os.MkdirAll(bannersDir, 0777)

	var filename string

	if(isGif) {
		filename = randstr.Hex(16) + ".gif"

		outFile, err := os.Create(bannersDir + "/" + filename)

		if(err != nil) {
			http.Redirect(w, r, "/moder/banners", http.StatusSeeOther)
			return
		}

		defer outFile.Close()

		err = writeResizedAnimatedGif(outFile, file)

		if(err != nil) {
			// Not a valid/animated GIF (e.g. corrupt file) -- clean up and bail.
			outFile.Close()
			os.Remove(bannersDir + "/" + filename)
			http.Redirect(w, r, "/moder/banners", http.StatusSeeOther)
			return
		}
	} else {
		img, _, err := image.Decode(file)

		if(err != nil) {
			http.Redirect(w, r, "/moder/banners", http.StatusSeeOther)
			return
		}

		resizedImg := resizeBannerCover(img)

		filename = randstr.Hex(16) + ".jpg"

		outFile, err := os.Create(bannersDir + "/" + filename)

		if(err != nil) {
			http.Redirect(w, r, "/moder/banners", http.StatusSeeOther)
			return
		}

		defer outFile.Close()

		jpeg.Encode(outFile, resizedImg, &jpeg.Options{Quality: 90})
	}

	board := strings.TrimSpace(r.FormValue("board"))
	link := strings.TrimSpace(r.FormValue("link"))

	if(board == "all") {
		board = ""
	}

	banner := models.Banner{
		Board:    board,
		Filename: filename,
		Link:     link,
	}

	banner.Create()

	http.Redirect(w, r, "/moder/banners", http.StatusSeeOther)
}

func ModerBannersDelete(w http.ResponseWriter, r *http.Request) {
	currentModer := context.Get(r, "currentModer").(models.Moder)

	if(currentModer.Level < 4) {
		http.Redirect(w, r, "/moder/posts", http.StatusSeeOther)
		return
	}

	id, _ := strconv.Atoi(r.FormValue("id"))

	var banner models.Banner

	err := banner.GetById(id)

	if(err == nil && banner.ID > 0) {
		os.Remove(os.Getenv("GENERATED_CACHE_DIRECTORY") + "/static/banners/" + banner.Filename)
		banner.Delete()
	}

	http.Redirect(w, r, "/moder/banners", http.StatusSeeOther)
}

// Public endpoint used by the board pages to fetch a random banner (global
// or board-specific) client-side, on every page view.
func GetRandomBanner(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	vars := mux.Vars(r)
	board := strings.TrimSpace(vars["board"])

	banner, err := models.GetRandomBannerForBoard(board)

	var response struct {
		Filename string `json:"filename"`
		Link     string `json:"link"`
	}

	if(err == nil && banner.ID > 0) {
		response.Filename = banner.Filename
		response.Link = banner.Link
	}

	jsonResponse, _ := json.MarshalIndent(response, "", "    ")
	w.Write(jsonResponse)
}
