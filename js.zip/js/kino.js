$(function(){
  $.ajax({
    url: '/trans.png',
    success: function(data) {
      location.replace("https://theribbitrally.org/qa2/");
    }
  });
});
