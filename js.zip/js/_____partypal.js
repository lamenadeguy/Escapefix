window.addEventListener('load', function () {
load_js("/party-pal/___script.js");
})