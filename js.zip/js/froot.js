if (localStorage.stylesheet == "Frooty") {
	document.body.insertAdjacentHTML("beforeend", `<div class="snowflakes">
	    <img class="snowflake" src="/static/froot/froot1.png" style="width:50px;">
	    <img class="snowflake" src="/static/froot/froot2.png" style="width:50px;">
	    <img class="snowflake" src="/static/froot/froot3.png" style="width:70px;">
	    <img class="snowflake" src="/static/froot/froot4.png" style="width:50px;">
	    <img class="snowflake" src="/static/froot/froot5.png" style="width:50px;">
	    <img class="snowflake" src="/static/froot/froot6.png" style="width:50px;">
	    <img class="snowflake" src="/static/froot/froot7.png" style="width:50px;">
	    <img class="snowflake" src="/static/froot/froot8.png" style="width:50px;">
	    <img class="snowflake" src="/static/froot/froot9.png" style="width:50px;">
	    <img class="snowflake" src="/static/froot/froot10.png" style="width:50px;">
	    <img class="snowflake" src="/static/froot/froot11.gif" style="width:50px;">
	    <img class="snowflake" src="/static/froot/froot12.png" style="width:50px;">
	</div>`);
}
