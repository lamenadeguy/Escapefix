-- SoyBooru (Nuuru) PHP port — SQLite schema
-- This is a minimal starting schema: only what the home page and
-- registration flow need. Later pieces (posts, tags, forum, etc.)
-- will add their own tables here as they get ported.

CREATE TABLE IF NOT EXISTS users (
    id              TEXT PRIMARY KEY,          -- UUID, matches the .NET ApplicationUser.Id style
    user_name       TEXT NOT NULL UNIQUE,
    password_hash   TEXT NOT NULL,
    role            TEXT NOT NULL DEFAULT 'User',
    biography       TEXT NOT NULL DEFAULT '',
    status          TEXT NOT NULL DEFAULT '',
    avatar_url      TEXT,
    background_image_url TEXT,
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS site_settings (
    key             TEXT PRIMARY KEY,
    value           TEXT NOT NULL
);

INSERT OR IGNORE INTO site_settings (key, value) VALUES ('registration_enabled', '1');

-- Booru posts (images only for now — video/audio/swf come later)
CREATE TABLE IF NOT EXISTS posts (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    uploader_id         TEXT NOT NULL REFERENCES users(id),
    filename            TEXT NOT NULL,      -- stored filename in public/uploads/
    original_filename   TEXT NOT NULL,
    mime_type           TEXT NOT NULL,
    width               INTEGER,
    height              INTEGER,
    file_size           INTEGER NOT NULL,
    has_thumbnail       INTEGER NOT NULL DEFAULT 0,
    rating              TEXT NOT NULL DEFAULT 'safe',        -- safe | questionable | explicit
    category            TEXT NOT NULL DEFAULT 'gallery',     -- gallery | artworks
    source              TEXT,
    description         TEXT,
    created_at          TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS post_votes (
    post_id     INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    value       INTEGER NOT NULL, -- 1 or -1
    PRIMARY KEY (post_id, user_id)
);

CREATE TABLE IF NOT EXISTS post_favorites (
    post_id     INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (post_id, user_id)
);

CREATE TABLE IF NOT EXISTS tags (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    category    TEXT
);

CREATE TABLE IF NOT EXISTS post_tags (
    post_id     INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    tag_id      INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (post_id, tag_id)
);

CREATE INDEX IF NOT EXISTS idx_post_tags_tag ON post_tags(tag_id);
CREATE INDEX IF NOT EXISTS idx_post_tags_post ON post_tags(post_id);

-- Emote reactions (posts only for now — comments/etc. come later)
CREATE TABLE IF NOT EXISTS reactions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_type     TEXT NOT NULL DEFAULT 'post',
    entity_id       INTEGER NOT NULL,
    user_id         TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    emote_name      TEXT NOT NULL,
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (entity_type, entity_id, user_id, emote_name)
);

CREATE INDEX IF NOT EXISTS idx_reactions_entity ON reactions(entity_type, entity_id);

-- Friends / enemies (one row per direction; type is 'friend' or 'enemy')
CREATE TABLE IF NOT EXISTS user_relations (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    target_user_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type            TEXT NOT NULL, -- 'friend' | 'enemy'
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (user_id, target_user_id, type)
);

-- Simple 5-minute cooldown between relation actions on the same target,
-- to match the original's anti-spam cooldown.
CREATE TABLE IF NOT EXISTS relation_cooldowns (
    user_id         TEXT NOT NULL,
    target_user_id  TEXT NOT NULL,
    last_action_at  TEXT NOT NULL,
    PRIMARY KEY (user_id, target_user_id)
);

-- Notifications
CREATE TABLE IF NOT EXISTS notifications (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id                 TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, -- recipient
    type                    TEXT NOT NULL,
    message                 TEXT NOT NULL,
    triggered_by_user_id    TEXT REFERENCES users(id) ON DELETE SET NULL,
    related_post_id         INTEGER REFERENCES posts(id) ON DELETE CASCADE,
    is_read                 INTEGER NOT NULL DEFAULT 0,
    created_at              TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);

-- Comments on posts. content is stored as plain text (no BBCode
-- pipeline ported yet — see Comment.php), rendered with
-- nl2br(e(...)) same as post descriptions. Imageboard-style ">>N"
-- reply references (N = another comment's id) are parsed straight
-- out of that plain text at render time — no separate column needed,
-- see Comment.php's linkify_reply_references().
CREATE TABLE IF NOT EXISTS comments (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id         INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    user_id         TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    content         TEXT NOT NULL,
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    edited_at       TEXT
);

CREATE INDEX IF NOT EXISTS idx_comments_post ON comments(post_id, created_at);

