<?php

declare(strict_types=1);

function render_vote_buttons(int $postId, array $voteState, bool $loggedIn): string
{
    $upRatio = ($voteState['upvotes'] + $voteState['downvotes']) > 0
        ? ($voteState['upvotes'] / ($voteState['upvotes'] + $voteState['downvotes'])) * 100
        : 50;
    $disabledAttr = $loggedIn ? '' : 'disabled';
    $disabledClass = $loggedIn ? '' : 'opacity-50 cursor-not-allowed';
    $upActive = $voteState['userVote'] === 1 ? 'text-[#ff4500]' : '';
    $downActive = $voteState['userVote'] === -1 ? 'text-[#7193ff]' : '';
    $scoreColor = $voteState['score'] > 0 ? 'text-[#ff4500]' : ($voteState['score'] < 0 ? 'text-[#7193ff]' : '');

    return '
    <div class="flex flex-col gap-1 w-full vote-widget" data-post-id="' . $postId . '">        <div class="flex items-center justify-between border border-border/50 px-1 h-8 bg-card shadow-[2px_2px_0_0_rgba(0,0,0,0.25)] ' . $disabledClass . '">
            <div class="flex items-center gap-0">
                <span class="text-sm font-bold text-[#ff4500] pl-1 pr-0.5 vote-upvotes">' . (int) $voteState['upvotes'] . '</span>
                <button type="button" class="vote-up-btn h-7 w-7 p-0 hover:bg-[#ff4500]/10 inline-flex items-center justify-center ' . $upActive . '" ' . $disabledAttr . ' title="Upvote">
                    <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M7 10v12M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z"/></svg>
                </button>
            </div>
            <span class="min-w-[2rem] text-center text-sm font-bold px-2 vote-score ' . $scoreColor . '">' . (int) $voteState['score'] . '</span>
            <div class="flex items-center gap-0">
                <button type="button" class="vote-down-btn h-7 w-7 p-0 hover:bg-[#7193ff]/10 inline-flex items-center justify-center ' . $downActive . '" ' . $disabledAttr . ' title="Downvote">
                    <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 14V2M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22h0a3.13 3.13 0 0 1-3-3.88Z"/></svg>
                </button>
                <span class="text-sm font-bold text-[#7193ff] pl-0.5 pr-1 vote-downvotes">' . (int) $voteState['downvotes'] . '</span>
            </div>
        </div>
        <div class="w-full h-[3px] bg-[#7193ff] flex overflow-hidden">
            <div class="h-full bg-[#ff4500] transition-all duration-500 vote-ratio-bar" style="width: ' . $upRatio . '%"></div>
        </div>
    </div>';
}

function render_favorite_button(int $postId, array $favoriteState, bool $loggedIn, string $extraClass = '', bool $mobile = false): string
{
    $disabledAttr = $loggedIn ? '' : 'disabled';
    $activeClass = $favoriteState['isFavorited'] ? 'text-red-500' : '';
    $sizeClass = $mobile ? 'h-8 w-8 p-0' : 'h-8 px-2 gap-1';

    return '
    <button type="button" class="favorite-btn inline-flex items-center justify-center ' . $sizeClass . ' border border-input bg-card shadow-[2px_2px_0_0_rgba(0,0,0,0.25)] hover:bg-accent ' . $activeClass . ' ' . $extraClass . '"
            data-post-id="' . $postId . '"
            ' . $disabledAttr . ' title="' . ($favoriteState['isFavorited'] ? 'Remove from favorites' : 'Add to favorites') . '">
        <svg class="h-4 w-4 favorite-icon" viewBox="0 0 24 24" fill="' . ($favoriteState['isFavorited'] ? 'currentColor' : 'none') . '" stroke="currentColor" stroke-width="2"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
        ' . (!$mobile ? '<span class="favorite-count text-sm font-bold">' . (int) $favoriteState['favoriteCount'] . '</span>' : '') . '
    </button>';
}

function render_share_button(string $extraClass = '', bool $mobile = false): string
{
    $sizeClass = $mobile ? 'h-8 w-8 p-0' : 'h-8 px-2 gap-1';

    return '
    <button type="button" class="share-btn inline-flex items-center justify-center ' . $sizeClass . ' border border-input bg-card shadow-[2px_2px_0_0_rgba(0,0,0,0.25)] hover:bg-accent ' . $extraClass . '" title="Share post">
        <svg class="h-4 w-4 share-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
        ' . (!$mobile ? '<span class="share-label text-xs font-bold">Share</span>' : '') . '
    </button>';
}

function render_reactions_widget(int $postId, array $reactions, array $userReactions, bool $canReact, string $extraClass = ''): string
{
    return render_reactions_widget_for('post', $postId, $reactions, $userReactions, $canReact, $extraClass);
}

/**
 * Generic version of the reactions widget — same markup/behavior as
 * render_reactions_widget() but parameterized over entity type so it
 * can be reused for comment reactions (entity_type = 'comment') via
 * the generic Reaction class, exactly as the README says the schema
 * was designed to allow.
 */
function render_reactions_widget_for(string $entityType, int $entityId, array $reactions, array $userReactions, bool $canReact, string $extraClass = ''): string
{
    ob_start();
    ?>
    <div class="reactions-widget flex items-center gap-2 flex-wrap <?= e($extraClass) ?>"
         data-entity-type="<?= e($entityType) ?>"
         data-entity-id="<?= $entityId ?>"
         data-can-react="<?= $canReact ? '1' : '0' ?>"
         data-user-reactions='<?= e(json_encode($userReactions)) ?>'>
        <?php foreach ($reactions as $r): ?>
            <button
                type="button"
                class="reaction-badge flex items-center gap-1 px-1.5 py-0.5 text-xs border transition-colors <?= in_array($r['emoteName'], $userReactions, true) ? 'bg-primary/10 border-primary text-primary hover:bg-primary/20' : 'bg-muted/50 border-border hover:bg-muted hover:border-muted-foreground/30' ?> <?= $canReact ? '' : 'cursor-default' ?>"
                data-emote="<?= e($r['emoteName']) ?>"
                <?= $canReact ? '' : 'disabled' ?>
                title=":<?= e($r['emoteName']) ?>:"
            >
                <img src="<?= e(emote_url($r['emoteName'])) ?>" alt=":<?= e($r['emoteName']) ?>:" class="w-5 h-5 object-contain">
                <span class="font-medium reaction-count"><?= (int) $r['count'] ?></span>
            </button>
        <?php endforeach; ?>

        <?php if ($canReact): ?>
            <div class="relative inline-block reaction-picker-wrap">
                <button type="button" class="reaction-picker-btn h-6 w-6 p-0 rounded-full text-muted-foreground hover:bg-accent hover:text-accent-foreground inline-flex items-center justify-center" title="Add reaction">
                    <?= png_icon('/assets/icons/smiley.png', 'h-4 w-4') ?>
                </button>
                <div class="reaction-picker hidden absolute z-50 top-8 left-0 w-[280px] bg-popover text-popover-foreground border shadow-[2px_2px_0_0_rgba(0,0,0,0.25)] p-2">
                    <div class="flex items-center justify-between px-1 mb-1.5">
                        <span class="text-sm font-medium">Add reaction</span>
                        <span class="reaction-limit-label text-xs text-muted-foreground"></span>
                    </div>
                    <input type="text" class="reaction-search flex h-8 w-full border border-input bg-background px-2 mb-1.5 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" placeholder="Search emotes...">
                    <div class="grid grid-cols-8 gap-1 max-h-48 overflow-y-auto custom-scrollbar">
                        <?php foreach (\Nuuru\Emotes::VALID as $emote): ?>
                            <button type="button" class="reaction-picker-item h-7 w-7 p-0.5 flex items-center justify-center hover:bg-accent" data-emote="<?= e($emote) ?>" title=":<?= e($emote) ?>:">
                                <img src="<?= e(emote_url($emote)) ?>" alt="" class="w-full h-full object-contain" loading="lazy">
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php elseif (!$reactions): ?>
            <span class="text-xs text-muted-foreground italic"><a href="/auth/login" class="text-primary hover:underline">Log in</a> to react.</span>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

function render_rating_badge(array $post, array $currentRating, bool $isUploader): string
{
    ob_start();
    ?>
    <div class="flex items-center gap-2 shrink-0 rating-section" data-post-id="<?= (int) $post['id'] ?>">
        <span class="field-display rating-display inline-flex items-center text-[9px] h-[18px] px-1.5 font-bold <?= e($currentRating['class']) ?>"><?= e($currentRating['label']) ?></span>
        <?php if ($isUploader): ?>
            <button type="button" class="edit-field-btn h-6 w-6 p-0 hover:bg-accent inline-flex items-center justify-center opacity-60 hover:opacity-100" data-field="rating" title="Edit rating">
                <svg class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>
            </button>
            <form method="post" action="/post/<?= (int) $post['id'] ?>/update" class="edit-field-form hidden items-center gap-1" data-field="rating">
                <input type="hidden" name="field" value="rating">
                <select name="value" class="h-6 text-[10px] border border-input bg-background px-1">
                    <option value="safe" <?= $post['rating'] === 'safe' ? 'selected' : '' ?>>Safe</option>
                    <option value="questionable" <?= $post['rating'] === 'questionable' ? 'selected' : '' ?>>Questionable</option>
                    <option value="explicit" <?= $post['rating'] === 'explicit' ? 'selected' : '' ?>>Explicit</option>
                </select>
                <button type="submit" class="h-6 w-6 p-0 hover:bg-primary/10 inline-flex items-center justify-center text-primary" title="Save">&check;</button>
            </form>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

function render_category_badge(array $post, array $currentCategory, bool $isUploader): string
{
    ob_start();
    ?>
    <div class="flex items-center gap-2 shrink-0 category-section">
        <span class="field-display inline-flex items-center text-[9px] h-[18px] px-1.5 font-bold <?= e($currentCategory['class']) ?>"><?= e($currentCategory['label']) ?></span>
        <?php if ($isUploader): ?>
            <button type="button" class="edit-field-btn h-6 w-6 p-0 hover:bg-accent inline-flex items-center justify-center opacity-60 hover:opacity-100" data-field="category" title="Edit category">
                <svg class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>
            </button>
            <form method="post" action="/post/<?= (int) $post['id'] ?>/update" class="edit-field-form hidden items-center gap-1" data-field="category">
                <input type="hidden" name="field" value="category">
                <select name="value" class="h-6 text-[10px] border border-input bg-background px-1">
                    <option value="gallery" <?= $post['category'] === 'gallery' ? 'selected' : '' ?>>Gallery</option>
                    <option value="artworks" <?= $post['category'] === 'artworks' ? 'selected' : '' ?>>Artworks</option>
                </select>
                <button type="submit" class="h-6 w-6 p-0 hover:bg-primary/10 inline-flex items-center justify-center text-primary" title="Save">&check;</button>
            </form>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

function render_source_row(array $post, bool $isUploader, bool $showTitle = false): string
{
    $source = $post['source'];
    ob_start();
    ?>
    <div class="flex items-center gap-2 min-w-0 source-section">
        <?php if ($showTitle): ?><span class="text-[10px] font-bold text-muted-foreground tracking-tight shrink-0">Source</span><?php endif; ?>
        <span class="field-display flex items-center gap-2 min-w-0 truncate">
            <?php if ($source): ?>
                <a href="<?= e($source) ?>" target="_blank" rel="noopener noreferrer" class="text-xs text-primary hover:underline truncate"><?= e($source) ?></a>
            <?php else: ?>
                <span class="text-xs text-muted-foreground italic">No source</span>
            <?php endif; ?>
        </span>
        <?php if ($isUploader): ?>
            <button type="button" class="edit-field-btn h-6 w-6 p-0 hover:bg-accent inline-flex items-center justify-center opacity-60 hover:opacity-100 shrink-0" data-field="source" title="Edit source">
                <svg class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>
            </button>
            <form method="post" action="/post/<?= (int) $post['id'] ?>/update" class="edit-field-form hidden items-center gap-1 flex-1 min-w-0" data-field="source">
                <input type="hidden" name="field" value="source">
                <input type="text" name="value" value="<?= e($source ?? '') ?>" placeholder="https://..." class="h-6 flex-1 min-w-0 text-xs border border-input bg-background px-1.5">
                <button type="submit" class="h-6 w-6 p-0 hover:bg-primary/10 inline-flex items-center justify-center text-primary shrink-0" title="Save">&check;</button>
            </form>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

function render_description_section(array $post, bool $isUploader): string
{
    $description = $post['description'];
    ob_start();
    ?>
    <div class="relative flex flex-col gap-0 min-w-0 description-section">
        <div class="flex items-center justify-between pb-1">
            <span class="text-[10px] font-bold text-muted-foreground tracking-tight shrink-0">Description</span>
            <?php if ($isUploader): ?>
                <button type="button" class="edit-field-btn h-6 w-6 p-0 hover:bg-accent inline-flex items-center justify-center opacity-60 hover:opacity-100" data-field="description" title="Edit description">
                    <svg class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>
                </button>
            <?php endif; ?>
        </div>
        <?php if ($description): ?>
            <p class="field-display text-sm whitespace-pre-wrap break-words"><?= nl2br(e($description)) ?></p>
        <?php else: ?>
            <p class="field-display text-sm text-muted-foreground italic">No description</p>
        <?php endif; ?>
        <?php if ($isUploader): ?>
            <form method="post" action="/post/<?= (int) $post['id'] ?>/update" class="edit-field-form hidden flex-col gap-1.5 mt-1" data-field="description">
                <input type="hidden" name="field" value="description">
                <textarea name="value" rows="3" class="w-full text-sm border border-input bg-background px-2 py-1"><?= e($description ?? '') ?></textarea>
                <button type="submit" class="self-start h-7 px-3 text-xs border border-transparent bg-primary text-primary-foreground hover:bg-primary/90">Save</button>
            </form>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Comments section — 1:1 layout port of CommentsSection.tsx /
 * CommentItem.tsx, minus what needs subsystems this port doesn't have
 * yet: BBCode rich editor, mentions, anonymous ("Chud") comments,
 * report dialog, comment locking, and live (SignalR) updates. Content
 * is plain text (nl2br(e(...))), same treatment as post descriptions.
 * Replies use plain imageboard-style ">>N" references instead of the
 * original's BBCode [quote] blocks — see Comment.php docblock and
 * Comment::linkify_reply_references().
 */
function render_comments_section(int $postId, array $comments, array $commentReactions, ?array $user, ?string $commentError): string
{
    ob_start();
    ?>
    <div id="post-comments-container" class="space-y-4">
        <h3 id="post-comments-header" class="text-lg font-bold text-muted-foreground/80 flex items-center gap-2 mb-4 pb-0">
            Comments
            <?php if (count($comments) > 0): ?>
                <span id="post-comments-count" class="font-normal opacity-70">(<?= count($comments) ?>)</span>
            <?php endif; ?>
        </h3>

        <?php if ($commentError): ?>
            <div class="text-xs font-bold text-destructive border border-destructive/30 bg-destructive/10 px-3 py-2"><?= e($commentError) ?></div>
        <?php endif; ?>

        <?php if ($user): ?>
            <form method="post" action="/post/<?= $postId ?>/comments" id="comment-form" class="border border-border">
                <textarea name="content" id="comment-form-textarea" rows="3" maxlength="<?= \Nuuru\Comment::MAX_LENGTH ?>" required
                          placeholder="Write a comment... (>>N replies to comment #N)"
                          class="w-full min-h-[120px] p-3 bg-transparent resize-y focus:outline-none text-sm"></textarea>
                <div class="flex items-center justify-end gap-2 p-2 border-t border-border bg-muted/30">
                    <button type="submit" class="inline-flex items-center gap-1 h-8 px-3 text-xs border border-transparent bg-primary text-primary-foreground hover:bg-primary/90">
                        <?= png_icon('/assets/icons/letter.png', 'h-4 w-4') ?> Post Comment
                    </button>
                </div>
            </form>
        <?php else: ?>
            <div class="text-center text-muted-foreground text-sm py-3">
                <a href="/auth/login" class="text-primary hover:underline">Log in</a> to comment
            </div>
        <?php endif; ?>

        <?php if (!$comments): ?>
            <div id="post-comments-empty" class="text-center py-12 bg-muted/5 border-2 border-dashed border-border/50">
                <?= png_icon('/assets/icons/speechbubble.png', 'w-8 h-8 mx-auto mb-3 opacity-20') ?>
                <p class="text-xs font-bold text-muted-foreground/60">No comments yet.</p>
            </div>
        <?php else: ?>
            <div id="post-comments-list">
                <?php
                // Precompute "replied by" backlinks (like vichan/mitsuba's
                // "Replies:" line at the bottom of a post): scan every
                // comment's ">>N" references once, then each comment knows
                // who quoted it.
                $repliedBy = [];
                foreach ($comments as $c) {
                    preg_match_all('/&gt;&gt;(\d+)/', nl2br(e($c['content'])), $refs);
                    foreach (array_unique($refs[1]) as $refId) {
                        $repliedBy[(int) $refId][] = (int) $c['id'];
                    }
                }
                ?>
                <?php foreach ($comments as $comment): ?>
                    <?= render_comment_item(
                        $comment,
                        $commentReactions[$comment['id']] ?? ['reactions' => [], 'userReactions' => []],
                        $user,
                        $repliedBy[(int) $comment['id']] ?? []
                    ) ?>
                <?php endforeach; ?>
            </div>

        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

function render_comment_item(array $comment, array $reactionState, ?array $user, array $repliedByIds = []): string
{
    $isOwner = $user !== null && $user['id'] === $comment['user_id'];
    ob_start();
    ?>
    <div id="c<?= (int) $comment['id'] ?>" class="comment-item border-b border-border py-4 px-1 last:border-b-0 overflow-hidden">
        <div id="comment-header" class="flex items-center justify-between gap-2 mb-3">
            <div id="comment-author-container" class="flex items-center gap-2 min-w-0">
                <div id="comment-avatar" class="shrink-0">
                    <a href="/user/<?= e($comment['author_name']) ?>">
                        <?= user_avatar_html(['id' => $comment['user_id'], 'avatarUrl' => $comment['author_avatar_url']], 'h-8 w-8') ?>
                    </a>
                </div>
                <div id="comment-author-info" class="flex flex-col sm:flex-row sm:items-center gap-x-2 gap-y-0 min-w-0">
                    <a id="comment-author-name" href="/user/<?= e($comment['author_name']) ?>" class="font-bold text-sm sm:text-base hover:underline truncate">
                        <?= e($comment['author_name']) ?>
                    </a>
                    <div id="comment-meta" class="flex items-center gap-2">
                        <span id="comment-date" class="text-[9px] sm:text-xs text-muted-foreground whitespace-nowrap" title="<?= e($comment['created_at']) ?>">
                            <?= e(relative_time($comment['created_at'])) ?>
                        </span>
                        <a href="#c<?= (int) $comment['id'] ?>" class="comment-anchor-link text-[9px] sm:text-xs font-bold text-primary hover:underline whitespace-nowrap" data-comment-id="<?= (int) $comment['id'] ?>" title="Reply to this comment">#<?= (int) $comment['id'] ?></a>
                        <?php if ($comment['edited_at']): ?>
                            <span id="comment-edited-label" class="comment-edited-label text-[9px] sm:text-xs text-muted-foreground italic whitespace-nowrap" title="<?= e($comment['edited_at']) ?>">(edited <?= e(relative_time($comment['edited_at'])) ?>)</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div id="comment-actions" class="comment-actions flex items-center gap-0.5 sm:gap-2 shrink-0">
                <?php if ($isOwner): ?>
                    <button type="button" class="comment-edit-btn h-5 w-5 sm:h-8 sm:w-8 p-0 hover:bg-accent hover:text-accent-foreground inline-flex items-center justify-center">
                        <?= png_icon('/assets/icons/pen.png', 'h-4 w-4') ?>
                    </button>
                    <button type="button" class="comment-delete-btn h-5 w-5 sm:h-8 sm:w-8 p-0 hover:bg-accent text-muted-foreground hover:text-destructive inline-flex items-center justify-center">
                        <?= png_icon('/assets/icons/trashcan.png', 'h-4 w-4') ?>
                    </button>
                    <span class="comment-delete-confirm hidden items-center gap-1 bg-destructive/10 px-1 border border-destructive/20">
                        <span class="text-[9px] font-bold text-destructive">Del?</span>
                        <button type="button" class="comment-delete-yes-btn h-5 px-1.5 text-[10px] text-destructive hover:bg-destructive/20">Yes</button>
                        <button type="button" class="comment-delete-no-btn h-5 px-1.5 text-[10px] hover:bg-accent">No</button>
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <div id="comment-content-container" class="pl-0 sm:pl-10">
            <div id="comment-body-container" class="space-y-3">
                <div id="comment-body" class="comment-body text-sm break-words whitespace-pre-wrap [overflow-wrap:anywhere]"><?= \Nuuru\Comment::linkify_reply_references(nl2br(e($comment['content']))) ?></div>
                <?php if ($isOwner): ?>
                    <form class="comment-edit-form hidden flex-col gap-1.5" data-comment-id="<?= (int) $comment['id'] ?>">
                        <textarea class="comment-edit-textarea w-full min-h-[80px] p-2 text-sm border border-input bg-background" maxlength="<?= \Nuuru\Comment::MAX_LENGTH ?>"><?= e($comment['content']) ?></textarea>
                        <div class="flex items-center gap-2">
                            <button type="button" class="comment-edit-save-btn h-7 px-3 text-xs border border-transparent bg-primary text-primary-foreground hover:bg-primary/90">Save</button>
                            <button type="button" class="comment-edit-cancel-btn h-7 px-3 text-xs hover:bg-accent">Cancel</button>
                        </div>
                    </form>
                <?php endif; ?>
                <div id="comment-reactions" class="pt-1">
                    <?= render_reactions_widget_for('comment', (int) $comment['id'], $reactionState['reactions'], $reactionState['userReactions'], $user !== null) ?>
                </div>
                <?php if ($repliedByIds): ?>
                    <div class="comment-replied-by text-[10px] sm:text-xs text-muted-foreground flex flex-wrap items-center gap-x-1.5 pt-0.5">
                        <span class="opacity-70">Replies:</span>
                        <?php foreach ($repliedByIds as $replyId): ?>
                            <a href="#c<?= $replyId ?>" class="comment-anchor-jump text-primary font-bold hover:underline" data-comment-id="<?= $replyId ?>">&gt;&gt;<?= $replyId ?></a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}


