<?php
/** @var array<string, mixed> $post */
/** @var array<int, array{emoteName:string, count:int}> $reactions */
/** @var array<int, string> $userReactions */
/** @var bool $canReact */
/** @var bool $isUploader */
/** @var array{score:int, upvotes:int, downvotes:int, userVote:int} $voteState */
/** @var array{isFavorited:bool, favoriteCount:int} $favoriteState */
/** @var ?array{id:string,userName:string,role:string} $user */
/** @var array<int, array<string, mixed>> $comments */
/** @var array<int, array{reactions: array<int, array{emoteName:string, count:int}>, userReactions: array<int, string>}> $commentReactions */

require __DIR__ . '/_post_widgets.php';

$RATING_LABELS = [
    'safe' => ['label' => 'Safe', 'class' => 'bg-green-600 text-white'],
    'questionable' => ['label' => 'Questionable', 'class' => 'bg-yellow-500 text-black'],
    'explicit' => ['label' => 'Explicit', 'class' => 'bg-red-600 text-white'],
];
$CATEGORY_LABELS = [
    'gallery' => ['label' => 'Gallery', 'class' => 'bg-blue-600 text-white'],
    'artworks' => ['label' => 'Artworks', 'class' => 'bg-purple-600 text-white'],
];

$currentRating = $RATING_LABELS[$post['rating']] ?? $RATING_LABELS['safe'];
$currentCategory = $CATEGORY_LABELS[$post['category']] ?? $CATEGORY_LABELS['gallery'];
$upRatio = ($voteState['upvotes'] + $voteState['downvotes']) > 0
    ? ($voteState['upvotes'] / ($voteState['upvotes'] + $voteState['downvotes'])) * 100
    : 50;

// Small reusable block: renders a Tags list grouped (we don't have tag
// categories yet, so everything lands in one "Uncategorized"-less group).
function render_tag_pills(array $tags): string
{
    if (!$tags) {
        return '<p class="text-xs text-muted-foreground italic">No tags</p>';
    }
    $html = '<div class="flex flex-wrap gap-1 justify-start lg:justify-center">';
    foreach ($tags as $tag) {
        $name = e($tag['name']);
        $html .= '<a href="/booru?q=' . urlencode($tag['name']) . '" class="flex items-center px-1.5 py-0.5 gap-1 bg-muted/10 hover:bg-muted/20 text-xs font-medium hover:underline min-h-[24px]">' . $name . '</a>';
    }
    return $html . '</div>';
}
?>
<div class="space-y-2 lg:space-y-6">

    <div class="grid grid-cols-1 lg:grid-cols-[250px_1fr] gap-2 lg:gap-6">

        <!-- Left sidebar (desktop only) -->
        <aside class="space-y-4 hidden lg:block">
            <div class="border bg-card text-card-foreground shadow-[2px_2px_0_0_rgba(0,0,0,0.25)]">
                <div class="p-4 flex flex-col items-center">
                    <div class="w-[200px] space-y-1.5">
                        <div class="flex flex-col items-center gap-1.5 w-full">
                            <?= render_vote_buttons($post['id'], $voteState, $user !== null) ?>
                            <div class="flex items-center justify-center gap-1.5 w-full">
                                <?= render_favorite_button($post['id'], $favoriteState, $user !== null, 'flex-1') ?>
                                <a href="/post/<?= (int) $post['id'] ?>/watch" class="flex-1">
                                    <span class="inline-flex w-full items-center justify-center gap-1 h-6 sm:h-8 px-1.5 sm:px-2 border border-input bg-card hover:bg-accent hover:text-accent-foreground text-xs font-bold">
                                        Watch
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div class="flex items-center gap-1.5 w-full">
                            <?= render_share_button('flex-1') ?>
                            <?php if ($user): ?>
                                <a href="/post/<?= (int) $post['id'] ?>/report" class="flex-1">
                                    <span class="inline-flex w-full items-center justify-center gap-1 h-6 sm:h-8 px-1.5 sm:px-2 border border-input bg-card hover:bg-accent hover:text-accent-foreground text-xs font-bold">
                                        Report
                                    </span>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="w-full mt-4 flex justify-center">
                        <?= render_reactions_widget($post['id'], $reactions, $userReactions, $canReact, 'justify-center') ?>
                    </div>
                </div>
            </div>

            <div class="border bg-card text-card-foreground shadow-[2px_2px_0_0_rgba(0,0,0,0.25)]">
                <div class="p-4 flex flex-col items-center">
                    <div class="w-[200px] space-y-3">
                        <?php if (!$post['tags']): ?>
                            <p class="text-xs text-muted-foreground italic text-center">No tags yet</p>
                        <?php endif; ?>
                        <?= render_tag_pills($post['tags']) ?>
                    </div>
                </div>
            </div>
        </aside>

        <!-- Main content -->
        <div class="space-y-2 lg:space-y-6 min-w-0">

            <!-- Media viewer -->
            <div id="media-viewer" class="group relative bg-muted overflow-hidden flex items-center justify-center min-h-[200px]">
                <img id="media-viewer-img" src="/uploads/<?= e($post['filename']) ?>" alt="<?= e($post['original_filename']) ?>"
                     class="max-w-full max-h-[70vh] w-auto h-auto object-contain cursor-zoom-in">
                <div class="absolute top-4 right-4 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button type="button" id="media-fullscreen-btn" title="Fullscreen"
                            class="h-8 w-8 inline-flex items-center justify-center bg-background/80 backdrop-blur border border-border/50">
                        <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/></svg>
                    </button>
                    <a href="/uploads/<?= e($post['filename']) ?>" download="<?= e($post['original_filename']) ?>" title="Download"
                       class="h-8 w-8 inline-flex items-center justify-center bg-background/80 backdrop-blur border border-border/50">
                        <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    </a>
                </div>
            </div>
            <div id="media-fullscreen-overlay" class="hidden fixed inset-0 z-50 bg-black/95 flex items-center justify-center cursor-zoom-out">
                <img src="/uploads/<?= e($post['filename']) ?>" alt="" class="max-w-[95vw] max-h-[95vh] object-contain">
            </div>

            <!-- Mobile action bar -->
            <div class="flex flex-col gap-2 lg:hidden">
                <div class="flex items-center justify-between px-0">
                    <div class="flex items-center gap-1">
                        <?= render_vote_buttons($post['id'], $voteState, $user !== null) ?>
                    </div>
                    <div class="flex-1 flex justify-center px-0.5 min-w-0">
                        <?= render_reactions_widget($post['id'], $reactions, $userReactions, $canReact, 'justify-center') ?>
                    </div>
                    <div class="flex items-center flex-wrap gap-1">
                        <?= render_share_button('', true) ?>
                        <?= render_favorite_button($post['id'], $favoriteState, $user !== null, '', true) ?>
                    </div>
                </div>
            </div>

            <!-- Info card -->
            <div class="border bg-card text-card-foreground shadow-[2px_2px_0_0_rgba(0,0,0,0.1)]">
                <div class="pt-2 pb-4 px-3 sm:px-4">
                    <div class="flex flex-col gap-0.5">
                        <div class="flex flex-col lg:flex-row lg:items-center justify-between">
                            <div class="flex flex-col lg:flex-row lg:items-center gap-x-4 gap-y-2 min-w-0">

                                <div class="flex items-center gap-2 min-w-0">
                                    <a href="/user/<?= e($post['uploader_name']) ?>">
                                        <?= user_avatar_html(['id' => $post['uploader_id'], 'avatarUrl' => $post['uploader_avatar_url']], 'h-8 w-8') ?>
                                    </a>
                                    <div class="flex flex-col gap-0 truncate">
                                        <a href="/user/<?= e($post['uploader_name']) ?>" class="text-sm font-bold hover:text-primary truncate"><?= e($post['uploader_name']) ?></a>
                                        <span class="text-[10px] text-muted-foreground whitespace-nowrap"><?= e($post['created_at']) ?></span>
                                    </div>
                                </div>

                                <div class="h-4 w-[1px] bg-border hidden lg:block"></div>

                                <div class="hidden lg:flex flex-col gap-y-0.5 min-w-0 flex-1">
                                    <div class="flex items-center gap-2">
                                        <?= render_rating_badge($post, $currentRating, $isUploader) ?>
                                        <?= render_category_badge($post, $currentCategory, $isUploader) ?>
                                    </div>
                                    <?= render_source_row($post, $isUploader, true) ?>
                                </div>
                            </div>

                            <div class="flex items-center gap-3 ml-auto lg:ml-0">
                                <div class="text-[10px] sm:text-xs text-muted-foreground hidden lg:flex items-center gap-1.5 font-mono">
                                    <div class="flex items-center gap-0.5 mr-1">
                                        <a href="/post/view/<?= max(1, $post['id'] - 1) ?>" class="h-5 w-5 inline-flex items-center justify-center hover:bg-accent" title="Previous Post">&lsaquo;</a>
                                        <span class="opacity-70">#<?= (int) $post['id'] ?></span>
                                        <a href="/post/view/<?= $post['id'] + 1 ?>" class="h-5 w-5 inline-flex items-center justify-center hover:bg-accent" title="Next Post">&rsaquo;</a>
                                    </div>
                                    <span>&bull;</span>
                                    <span><?= e(format_file_size((int) $post['file_size'])) ?></span>
                                    <?php if ($post['width'] && $post['height']): ?>
                                        <span>&bull;</span>
                                        <span><?= (int) $post['width'] ?>&times;<?= (int) $post['height'] ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Description -->
                        <div class="border-t pt-2 mt-2">
                            <?= render_description_section($post, $isUploader) ?>
                        </div>

                        <!-- Mobile-only rating/category/source/tags -->
                        <div class="lg:hidden pt-2 border-t mt-2 flex flex-col gap-2">
                            <div class="flex items-center gap-2">
                                <?= render_rating_badge($post, $currentRating, $isUploader) ?>
                                <?= render_category_badge($post, $currentCategory, $isUploader) ?>
                            </div>
                            <?= render_source_row($post, $isUploader, true) ?>
                            <div class="pt-1">
                                <span class="text-[10px] font-bold text-muted-foreground tracking-tight">Tags</span>
                                <div class="pt-1"><?= render_tag_pills($post['tags']) ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Comments -->
            <div class="border bg-card text-card-foreground shadow-[2px_2px_0_0_rgba(0,0,0,0.1)] p-3 sm:p-4">
                <?= render_comments_section(
                    (int) $post['id'],
                    $comments,
                    $commentReactions,
                    $user,
                    isset($_GET['comment_error']) ? (string) $_GET['comment_error'] : null
                ) ?>
            </div>

        </div>
    </div>

</div>

<script>
(function () {
    const overlay = document.getElementById('media-fullscreen-overlay');
    const btn = document.getElementById('media-fullscreen-btn');
    const img = document.getElementById('media-viewer-img');
    function open() { overlay.classList.remove('hidden'); }
    function close() { overlay.classList.add('hidden'); }
    btn.addEventListener('click', open);
    img.addEventListener('click', open);
    overlay.addEventListener('click', close);
})();

// --- Share button(s) ---
document.querySelectorAll('.share-btn').forEach(function (btn) {
    btn.addEventListener('click', async function () {
        const url = window.location.href;
        try {
            await navigator.clipboard.writeText(url);
            const label = btn.querySelector('.share-label');
            if (label) {
                const original = label.textContent;
                label.textContent = 'Copied!';
                setTimeout(function () { label.textContent = original; }, 2000);
            }
        } catch (e) { /* clipboard not available, silently ignore */ }
    });
});

// --- Favorite button(s) ---
document.querySelectorAll('.favorite-btn').forEach(function (btn) {
    btn.addEventListener('click', async function () {
        if (btn.disabled) return;
        const postId = btn.dataset.postId;
        const res = await fetch('/api/posts/' + postId + '/favorite', { method: 'POST' });
        const data = await res.json();
        if (!res.ok) { alert(data.error || 'Something went wrong.'); return; }
        document.querySelectorAll('.favorite-btn[data-post-id="' + postId + '"]').forEach(function (b) {
            b.classList.toggle('text-red-500', data.isFavorited);
            const icon = b.querySelector('.favorite-icon');
            if (icon) icon.setAttribute('fill', data.isFavorited ? 'currentColor' : 'none');
            const count = b.querySelector('.favorite-count');
            if (count) count.textContent = data.favoriteCount;
        });
    });
});

// --- Vote buttons ---
function renderVoteState(postId, state) {
    document.querySelectorAll('.vote-widget[data-post-id="' + postId + '"]').forEach(function (widget) {
        widget.querySelector('.vote-upvotes').textContent = state.upvotes;
        widget.querySelector('.vote-downvotes').textContent = state.downvotes;
        const scoreEl = widget.querySelector('.vote-score');
        scoreEl.textContent = state.score;
        scoreEl.classList.remove('text-[#ff4500]', 'text-[#7193ff]');
        if (state.score > 0) scoreEl.classList.add('text-[#ff4500]');
        if (state.score < 0) scoreEl.classList.add('text-[#7193ff]');
        const upBtn = widget.querySelector('.vote-up-btn');
        const downBtn = widget.querySelector('.vote-down-btn');
        upBtn.classList.toggle('text-[#ff4500]', state.userVote === 1);
        downBtn.classList.toggle('text-[#7193ff]', state.userVote === -1);
        const total = state.upvotes + state.downvotes;
        const ratio = total > 0 ? (state.upvotes / total) * 100 : 50;
        widget.querySelector('.vote-ratio-bar').style.width = ratio + '%';
    });
}

document.querySelectorAll('.vote-widget').forEach(function (widget) {
    const postId = widget.dataset.postId;
    async function sendVote(value) {
        const res = await fetch('/api/posts/' + postId + '/vote', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ value: value }),
        });
        const data = await res.json();
        if (!res.ok) { alert(data.error || 'Something went wrong.'); return; }
        renderVoteState(postId, data);
        currentUserVote[postId] = data.userVote;
    }
    widget.querySelector('.vote-up-btn').addEventListener('click', function () {
        if (this.disabled) return;
        sendVote(currentUserVote[postId] === 1 ? 0 : 1);
    });
    widget.querySelector('.vote-down-btn').addEventListener('click', function () {
        if (this.disabled) return;
        sendVote(currentUserVote[postId] === -1 ? 0 : -1);
    });
});
var currentUserVote = { <?= (int) $post['id'] ?>: <?= (int) $voteState['userVote'] ?> };

// --- Reactions (supports multiple widgets for the same entity, e.g.
//     desktop + mobile post widgets, plus one widget per comment) ---
const MAX_REACTIONS = 3;
function renderReactions(entityType, entityId, reactions, userReactions) {
    document.querySelectorAll('.reactions-widget[data-entity-type="' + entityType + '"][data-entity-id="' + entityId + '"]').forEach(function (container) {
        container.dataset.userReactions = JSON.stringify(userReactions);
        container.querySelectorAll('.reaction-badge').forEach(function (el) { el.remove(); });
        const pickerWrap = container.querySelector('.reaction-picker-wrap');
        const loginMsg = container.querySelector('span');
        reactions.forEach(function (r) {
            const b = document.createElement('button');
            b.type = 'button';
            b.className = 'reaction-badge flex items-center gap-1 px-1.5 py-0.5 text-xs border transition-colors ' +
                (userReactions.includes(r.emoteName)
                    ? 'bg-primary/10 border-primary text-primary hover:bg-primary/20'
                    : 'bg-muted/50 border-border hover:bg-muted hover:border-muted-foreground/30');
            b.dataset.emote = r.emoteName;
            b.title = ':' + r.emoteName + ':';
            b.innerHTML = '<img src="/assets/emotes/' + encodeURIComponent(r.emoteName) + '.png" alt="" class="w-5 h-5 object-contain"><span class="font-medium reaction-count">' + r.count + '</span>';
            b.addEventListener('click', function () { toggleReaction(entityType, entityId, r.emoteName); });
            if (pickerWrap) container.insertBefore(b, pickerWrap);
            else if (loginMsg) container.insertBefore(b, loginMsg);
            else container.appendChild(b);
        });
        const limitLabel = container.querySelector('.reaction-limit-label');
        if (limitLabel) limitLabel.textContent = userReactions.length + '/' + MAX_REACTIONS;
    });
}

async function toggleReaction(entityType, entityId, emoteName) {
    const endpoint = entityType === 'comment'
        ? '/api/comments/' + entityId + '/reactions'
        : '/api/posts/' + entityId + '/reactions';
    const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emoteName: emoteName }),
    });
    const data = await res.json();
    if (!res.ok) { alert(data.error || 'Something went wrong.'); return; }
    renderReactions(entityType, entityId, data.reactions, data.userReactions);
}

document.querySelectorAll('.reactions-widget').forEach(function (container) {
    const entityType = container.dataset.entityType || 'post';
    const entityId = container.dataset.entityId;
    container.querySelectorAll('.reaction-badge').forEach(function (btn) {
        btn.addEventListener('click', function () { toggleReaction(entityType, entityId, btn.dataset.emote); });
    });
    const pickerBtn = container.querySelector('.reaction-picker-btn');
    const picker = container.querySelector('.reaction-picker');
    if (pickerBtn && picker) {
        const search = picker.querySelector('.reaction-search');
        const limitLabel = picker.querySelector('.reaction-limit-label');
        const userReactions = JSON.parse(container.dataset.userReactions || '[]');
        if (limitLabel) limitLabel.textContent = userReactions.length + '/' + MAX_REACTIONS;

        pickerBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            picker.classList.toggle('hidden');
            if (!picker.classList.contains('hidden') && search) search.focus();
        });
        document.addEventListener('click', function (e) {
            if (!picker.contains(e.target) && e.target !== pickerBtn) picker.classList.add('hidden');
        });
        if (search) {
            search.addEventListener('input', function () {
                const q = search.value.toLowerCase();
                picker.querySelectorAll('.reaction-picker-item').forEach(function (b) {
                    b.style.display = b.dataset.emote.includes(q) ? '' : 'none';
                });
            });
        }
        picker.querySelectorAll('.reaction-picker-item').forEach(function (b) {
            b.addEventListener('click', function () {
                picker.classList.add('hidden');
                toggleReaction(entityType, entityId, b.dataset.emote);
            });
        });
    }
});

// --- Comments: edit (inline) and delete (with confirm), AJAX so there's
//     no full page reload — matches the original's inline edit/delete UX.
document.querySelectorAll('.comment-item').forEach(function (item) {
    const commentId = item.id.replace(/^c/, '');
    const body = item.querySelector('.comment-body');
    const editBtn = item.querySelector('.comment-edit-btn');
    const editForm = item.querySelector('.comment-edit-form');
    const deleteBtn = item.querySelector('.comment-delete-btn');
    const deleteConfirm = item.querySelector('.comment-delete-confirm');

    if (editBtn && editForm && body) {
        const textarea = editForm.querySelector('.comment-edit-textarea');
        const saveBtn = editForm.querySelector('.comment-edit-save-btn');
        const cancelBtn = editForm.querySelector('.comment-edit-cancel-btn');

        editBtn.addEventListener('click', function () {
            body.classList.add('hidden');
            editForm.classList.remove('hidden');
            editForm.classList.add('flex');
            textarea.focus();
        });
        cancelBtn.addEventListener('click', function () {
            editForm.classList.add('hidden');
            editForm.classList.remove('flex');
            body.classList.remove('hidden');
            textarea.value = body.textContent.trim();
        });
        saveBtn.addEventListener('click', async function () {
            const content = textarea.value;
            const res = await fetch('/api/comments/' + commentId, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ content: content }),
            });
            const data = await res.json();
            if (!res.ok) { alert(data.error || 'Something went wrong.'); return; }
            body.innerHTML = data.contentHtml;
            body.classList.remove('hidden');
            editForm.classList.add('hidden');
            editForm.classList.remove('flex');
            let editedLabel = item.querySelector('.comment-edited-label');
            if (!editedLabel) {
                editedLabel = document.createElement('span');
                editedLabel.className = 'comment-edited-label text-[9px] sm:text-xs text-muted-foreground italic whitespace-nowrap';
                item.querySelector('#comment-meta').appendChild(editedLabel);
            }
            editedLabel.title = data.editedAt;
            editedLabel.textContent = '(edited ' + data.editedAtRelative + ')';
        });
    }

    if (deleteBtn && deleteConfirm) {
        const yesBtn = deleteConfirm.querySelector('.comment-delete-yes-btn');
        const noBtn = deleteConfirm.querySelector('.comment-delete-no-btn');

        deleteBtn.addEventListener('click', function () {
            deleteBtn.classList.add('hidden');
            deleteConfirm.classList.remove('hidden');
            deleteConfirm.classList.add('flex');
        });
        noBtn.addEventListener('click', function () {
            deleteConfirm.classList.add('hidden');
            deleteConfirm.classList.remove('flex');
            deleteBtn.classList.remove('hidden');
        });
        yesBtn.addEventListener('click', async function () {
            const res = await fetch('/api/comments/' + commentId + '/delete', { method: 'POST' });
            const data = await res.json();
            if (!res.ok) { alert(data.error || 'Something went wrong.'); return; }
            item.remove();
            const countEl = document.getElementById('post-comments-count');
            if (countEl) {
                const remaining = document.querySelectorAll('.comment-item').length;
                countEl.textContent = remaining > 0 ? '(' + remaining + ')' : '';
            }
        });
    }
});

// --- Comments: imageboard-style ">>N" replies ---
// Clicking a comment's "#N" anchor (in its header) inserts ">>N" into
// the comment form, the way clicking a post number on a vichan/
// mitsuba-style imageboard does. Clicking a ">>N" reference inside a
// comment's body (or a "Replies: >>M >>K" backlink) jumps to that
// comment and briefly highlights it. Delegated on the document so
// this keeps working after an inline edit replaces a comment body's
// innerHTML (new >>N references included) without rebinding anything.
(function () {
    const form = document.getElementById('comment-form');
    const textarea = document.getElementById('comment-form-textarea');

    function jumpTo(commentId) {
        const target = document.getElementById('c' + commentId);
        if (!target) return;
        target.scrollIntoView({ behavior: 'smooth', block: 'center' });
        target.classList.add('comment-highlight');
        setTimeout(function () { target.classList.remove('comment-highlight'); }, 1500);
    }

    document.addEventListener('click', function (e) {
        const anchorLink = e.target.closest('.comment-anchor-link');
        if (anchorLink) {
            if (!form || !textarea) return; // logged out — no form to reply into
            e.preventDefault();
            const ref = '>>' + anchorLink.dataset.commentId + '\n';
            const insertAt = textarea.selectionStart ?? textarea.value.length;
            textarea.value = textarea.value.slice(0, insertAt) + ref + textarea.value.slice(insertAt);
            form.scrollIntoView({ behavior: 'smooth', block: 'center' });
            textarea.focus();
            const caret = insertAt + ref.length;
            textarea.setSelectionRange(caret, caret);
            return;
        }

        const jumpLink = e.target.closest('.comment-reply-ref, .comment-anchor-jump');
        if (jumpLink) {
            e.preventDefault();
            jumpTo(jumpLink.dataset.refId || jumpLink.dataset.commentId);
        }
    });
})();

// --- Inline edit forms (rating / category / source / description) ---
document.querySelectorAll('.edit-field-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
        const field = btn.dataset.field;
        const scope = btn.closest('.rating-section, .category-section, .source-section, .description-section');
        if (!scope) return;
        btn.classList.add('hidden');
        const display = scope.querySelector('.field-display');
        if (display) display.classList.add('hidden');
        const form = scope.querySelector('.edit-field-form[data-field="' + field + '"]');
        if (form) {
            form.classList.remove('hidden');
            form.style.display = field === 'description' ? 'flex' : 'flex';
        }
    });
});
</script>
