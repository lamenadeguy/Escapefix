# SoyBooru (Nuuru) — PHP 8.4 port (work in progress)

This is the start of a port of the original .NET 10 + React engine to
plain PHP 8.4, using a single **SQLite** file instead of PostgreSQL so
there's nothing to configure.

Seven pages/areas are ported so far:

- **Homepage** (`/`) — 1:1 visual copy of the React landing page (logo,
  nav icons, tag search bar, "latest threads" strip).
- **Registration** (`/auth/register`) and **Login** (`/auth/login`) —
  same validation rules as the original, session-based (see below).
- **Profile** (`/user/{username}`) and **Settings** (`/settings`) —
  avatar (deterministic random-hue default, or upload your own),
  status/bio editing, password change, friend/enemy buttons.
- **Friends & Enemies** (`/user/{username}/relations`) and
  **Notifications** (`/notifications`, bell icon in the header).
- **Gallery** (`/booru`) — grid of uploaded posts with thumbnails,
  pagination, and tag search (`?q=tag1+tag2`, AND-matched); plus
  **Upload** (`/booru/upload`, login required, with rating/category/
  source/description fields) and a **post view** (`/post/view/{id}`)
  that's a 1:1 layout match of the original page — media viewer,
  vote buttons, favorite, share, emote reactions, rating/category/
  source/description (editable inline by the uploader), tags sidebar,
  desktop + mobile layouts, and **comments** (post, edit inline,
  delete with confirm, react to individual comments — see below for
  what's simplified).

## Requirements

- PHP 8.4 (also runs on 8.3 — nothing 8.4-only is used yet) with the
  **pdo_sqlite** and **mbstring** extensions enabled (both are on by
  default in most distro PHP packages / all major hosting panels).
- Node.js is only needed if you want to *rebuild* the CSS (see below).
  It is **not** needed to run the site — `public/assets/app.css` is
  already compiled and committed.

## Running it

```bash
cd public
php -S 0.0.0.0:8000 index.php
```

Then open http://localhost:8000/. The SQLite database file is created
automatically on first request at `database/nuuru.sqlite` (path is
git-ignored — delete it any time to reset all data).

For real deployment, point your web server's document root at
`public/` and route all requests through `index.php` (or just use
PHP-FPM + nginx/Apache with a rewrite rule `try_files $uri /index.php`).

## Project layout

```
public/            <- web root
  index.php        <- front controller / router
  assets/          <- images + compiled Tailwind CSS
src/
  Database.php     <- PDO/SQLite connection + schema bootstrap
  Auth.php         <- register/login/logout, session-based
  SiteSettings.php <- reads the site_settings table (e.g. registration on/off)
  helpers.php      <- view() renderer, e() escaper, redirect()
views/
  home.php
  auth/register.php
  auth/login.php   <- placeholder
  layout/          <- shared <head>/<header>/<footer>
database/
  schema.sql       <- SQLite schema: users (incl. background_image_url),
                      site_settings, posts, tags, post_tags, reactions,
                      post_votes, post_favorites, user_relations,
                      relation_cooldowns, notifications
                      (Database.php also runs tiny ALTER TABLE migrations
                      for columns added after a table already existed —
                      see Database::migrate())
build/
  input.css        <- Tailwind v4 source (same theme tokens as the original);
                      @source covers both views/ and src/, since some
                      icon-rendering helpers that generate class names
                      live in src/helpers.php
```

Uploaded images land in `public/uploads/` (git-ignored), thumbnails in
`public/uploads/thumbs/`. Make sure that folder is writable by whatever
user runs PHP (`www-data` typically):

```bash
mkdir -p public/uploads/thumbs
chown -R www-data:www-data public/uploads
```

## Important simplifications (please confirm these are OK)

The original engine is much bigger than these two pages, and some of
its plumbing doesn't make sense to port 1:1 yet:

1. **Auth is session-based, not JWT.** The original uses ASP.NET
   Identity + JWT access tokens with refresh-token rotation, built for
   a decoupled SPA. Since this PHP version renders pages on the
   server, a plain session cookie does the exact same job with far
   less code. This can be swapped later if the frontend ever talks to
   this backend as an API instead.
2. **No CAPTCHA / IP geo-verification on signup.** The original
   registration flow calls out to external services (hCaptcha-style
   check + an IP intelligence lookup that can hold new accounts for
   review). Those are external integrations, not core engine logic —
   left out for now, registration is "instant" like a plain signup
   form.
3. **The header is a stripped-down stand-in.** The real `<Header>`
   component has a mega-menu (Gallery/Forum/Popular/Boints/Admin/etc.)
   that depends on subsystems (forum, tags, boints, permissions) that
   don't exist in this port yet. `/auth/register` currently gets a
   minimal header with just the logo + login/register or username +
   logout, styled to match. It'll grow as more sections get ported.
4. **`/booru`, `/forum`, `/members`, `/settings`, etc. don't exist
   yet** — the homepage links to them for visual accuracy, but they'll
   404 until they're ported too. (`/booru` and `/booru/upload` are now
   live — see below.)
5. **Gallery search only supports plain tags.** The original supports
   meta-operators like `category:x` or `order:random` — this port
   strips anything with a colon out of the query for now, so only
   literal tag names work (space-separated, AND-matched).
6. **All uploads are instantly public, no moderation queue, no
   duplicate/hash detection, images only** (no video/audio/swf yet).
   Thumbnails are generated with GD when available; if GD isn't
   installed, the original file is used as its own "thumbnail" (fine
   for small images, wasteful for large ones).
7. **Reactions exist on posts and comments.** The schema (`entity_type`
   + `entity_id`) is generic, and it's now wired up for both `post` and
   `comment` — exactly the extension this note originally said would
   come "later."
8. **Editing rating/category/source/description is uploader-only,
   no moderator override yet** (the original also lets moderators with
   the right permission edit anyone's post — there's no permission
   system here yet, just "are you the uploader").
9. **Comments** — post, edit (inline, AJAX), delete (with a Yes/No
   confirm, AJAX), react to individual comments (reuses the same
   generic `Reaction` system as posts), and reply to a specific comment
   with plain imageboard-style `>>N` references (N = the comment's
   id) — clicking a comment's `#N` anchor inserts `>>N` into the reply
   box, clicking a `>>N` inside a comment's body (or the "Replies:
   >>M >>K" backlink line under a comment that's been replied to)
   jumps to and briefly highlights that comment. Commenting on someone
   else's post creates a "commented on your post" notification,
   matching the original's message text exactly. Simplified vs the
   original:
   - **Plain text only, no BBCode.** The original stores `ContentRaw`
     (BBCode) + `ContentHtml` (parsed/sanitized) and extracts
     `@mentions` and `[thumb]` embeds while parsing. None of that
     pipeline exists in this port, so comment content is stored and
     shown as plain text (`nl2br(e(...))`) — same treatment as post
     descriptions.
   - **`>>N` replies instead of `[quote]` blocks.** The original's
     reply-with-quote embeds the quoted comment's BBCode inline
     (`[quote commentId=.. hash=..]content[/quote]`, HMAC-signed so a
     stateless renderer can tell it wasn't tampered with) and renders
     it as its own styled blockquote with an avatar/author header.
     Without a BBCode parser to generate or render that block, this
     port uses the plain `>>N` convention every imageboard already
     uses instead — no embedded copy of the quoted text, no signature
     needed, just a link. If the referenced comment is later deleted,
     the `>>N` simply points at nothing rather than showing a "quote
     unavailable" fallback — same tradeoff plain `>>N` links make
     anywhere else. No mention autocomplete/notifications, no
     embedding another post inline, no text-selection quoting.
   - **No anonymous ("Chud") comments.** The original lets logged-out
     visitors comment anonymously behind a captcha, gated by a site
     setting and a permission check. Neither the permission system nor
     a captcha integration exists here, so commenting requires being
     logged in, full stop — logged-out visitors see a "Log in to
     comment" prompt instead of a comment box.
   - **No comment locking, no report dialog.** Both are
     moderator/permission-gated features on the original `Post`/report
     system that don't exist in this port (same as "Report" on posts
     already being an inert 404 link elsewhere on this page).
   - **Delete is owner-only.** The original also allows moderators
     with `Permissions.Moderation.DeleteComment` — there's no
     permission system here yet, same caveat as item 8 above.
   - **No Boints credit, no auto-watch, no live (SignalR) updates.**
     Those subsystems don't exist in this port; posting a comment just
     re-renders the list on next load (or via the same-page AJAX for
     edit/delete/react) instead of pushing to other open tabs.
   - The post view page otherwise matches the original layout: media
     viewer, vote buttons, favorite, share, reactions, tags sidebar,
     and the info card with inline-editable rating/category/source/
     description. "Report" and "Watch" render as disabled/404 buttons
     (not wired up). Prev/Next post links just go to `id - 1` /
     `id + 1` without checking they exist — same as the original.
10. **Profiles** (`/user/{username}`) — avatar, status, bio, join date,
    upload/favorite counts, and a grid of the user's uploads. Not
    ported: friends/enemies, badges, boints/koints, forum stats,
    reaction score (all need subsystems that don't exist yet).
11. **Settings** (`/settings`) — status/biography, avatar upload
    (auto-cropped to a square, needs GD), password change. Not
    ported: custom CSS, background image, notification/privacy
    toggles (the mega-tabbed original settings page is ~950 lines;
    this covers the "edit who I am" essentials only).
12. **Default avatars** use the exact same hue-hashing algorithm as
    the original `UserAvatar.tsx` (hash the user's ID, use it as a
    CSS `hue-rotate()` on a grayscale placeholder image) — so it's a
    consistent color per user, not a literally-random one on every
    page load.
13. **Friends/enemies** (`/user/{username}/relations`, buttons on
    profiles) — direct add/remove, with the same 5-minute cooldown per
    target user to prevent spam. Both friends and enemies are
    symmetric: if A adds B, it shows up on both profiles without B
    doing anything (this matches how the original actually stores/
    queries friendships — a single row, checked from either direction;
    enemies were made symmetric the same way on request, whereas the
    original keeps enemies one-directional). Adding a friend clears an
    enemy mark between the two users and vice versa.
14. **Notifications** (`/notifications`, bell icon with unread badge
    in the header) — created for: someone adds you as a friend,
    removes you as a friend, marks you as an enemy, or reacts to your
    post. Matches the original's dedup behavior (won't spam you with
    a new "X reacted to your post" if you already have an unread one
    for that post). Not wired up: comments, mentions, forum, private
    messages, moderation notifications — those need subsystems that
    don't exist yet.
15. **Profile sidebar** (biography + optional background image,
    friends grid, enemies grid) matches the original's `UserInfoCard`
    layout: it only appears when there's something to show, and the
    page collapses to a single column otherwise. Background image
    sits behind the biography with the same fade-to-transparent mask
    and dark overlay as the original.
16. **Favorites page** (`/user/{username}/favorites`) — linked from
    the profile's Favorites button/stat, same grid as the gallery.
17. **Upload page** (`/booru/upload`) rebuilt to match the original's
    structure: Tutorial dialog (same tag-guideline copy and example
    images), a drag-and-drop file zone, Common Tags, the full Quicktag
    panel (every group/tag from the original — skin color, build,
    hair, expression, background, flags, etc. — click to append),
    Common Source, Common Description, and Rating/Category dropdowns
    styled like the original's (with descriptions + a checkmark on
    the selected option). Still single-file only (the original
    supports a multi-file batch queue, not built here yet), and
    there's no captcha/anonymous-upload path.
18. **Dark mode fix**: native browser controls (the `<select>`
    dropdown popups, the file input's "Browse" button, checkboxes)
    render with the OS's light chrome unless the page declares
    `color-scheme`. Added `color-scheme: light` / `.dark { color-scheme:
    dark }` so those switch themes along with everything else — this
    was the cause of some buttons/controls looking "wrong" in dark mode.
19. **More original buttons wired up as inert links** (per request,
    they intentionally 404 for now instead of doing nothing): Message,
    Report, and Give Koints on profiles; Watch and Report on posts;
    Forum/Members/Koints in the header nav and user dropdown. Nothing
    behind them exists yet, but the buttons are present like a normal
    "not built yet" 404 rather than being disabled or missing.

## Rebuilding the CSS (only if you change the views' class names)

```bash
cd build
npm install
npx tailwindcss -i ./input.css -o ../public/assets/app.css --minify
```

## What's next

Natural next slices, in roughly the order they unblock each other: a
BBCode parser (unlocks rich comment formatting, @mentions, comment
quoting, `[thumb]` embeds, and the same for post descriptions), tag
autocomplete + meta-search operators + tag categories/colors, a real
permission system (so moderators can edit others' posts, delete any
comment, and anonymous/captcha-gated comments become possible), the
real `Header` component, then forum, members, boints, admin.
