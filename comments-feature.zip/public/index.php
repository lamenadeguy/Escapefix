<?php

declare(strict_types=1);

session_start();

require __DIR__ . '/../src/helpers.php';

spl_autoload_register(function (string $class): void {
    $prefix = 'Nuuru\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }
    $relative = substr($class, strlen($prefix));
    $file = __DIR__ . '/../src/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

use Nuuru\Auth;
use Nuuru\Comment;
use Nuuru\Notification;
use Nuuru\Post;
use Nuuru\Reaction;
use Nuuru\Relation;
use Nuuru\SiteSettings;
use Nuuru\UserProfile;

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$path = rtrim($path, '/');
if ($path === '') {
    $path = '/';
}
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// --- Routes ---------------------------------------------------------------

if ($path === '/' && $method === 'GET') {
    view('home', [
        'title' => 'TheKuz.win',
        'user' => Auth::user(),
        'registrationEnabled' => SiteSettings::registrationEnabled(),
    ]);
    exit;
}

if ($path === '/auth/register') {
    if (Auth::check()) {
        redirect('/');
    }

    $registrationEnabled = SiteSettings::registrationEnabled();

    if ($method === 'POST' && $registrationEnabled) {
        $userName = trim((string) ($_POST['userName'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');
        $confirmPassword = (string) ($_POST['confirmPassword'] ?? '');

        $result = Auth::register($userName, $password, $confirmPassword);

        if ($result['success']) {
            redirect('/');
        }

        view('auth/register', [
            'title' => 'Register - TheKuz.win',
            'showHeader' => true,
            'registrationEnabled' => $registrationEnabled,
            'errors' => $result['errors'],
            'oldUserName' => $userName,
        ]);
        exit;
    }

    view('auth/register', [
        'title' => 'Register - TheKuz.win',
        'showHeader' => true,
        'registrationEnabled' => $registrationEnabled,
        'errors' => [],
        'oldUserName' => '',
    ]);
    exit;
}

if ($path === '/auth/login') {
    if (Auth::check()) {
        redirect('/');
    }

    if ($method === 'POST') {
        $userName = trim((string) ($_POST['userName'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');

        $result = Auth::login($userName, $password);

        if ($result['success']) {
            redirect('/');
        }

        view('auth/login', [
            'title' => 'Login - TheKuz.win',
            'showHeader' => true,
            'errors' => $result['errors'],
            'oldUserName' => $userName,
        ]);
        exit;
    }

    view('auth/login', [
        'title' => 'Login - TheKuz.win',
        'showHeader' => true,
        'errors' => [],
        'oldUserName' => '',
    ]);
    exit;
}

if ($path === '/auth/logout' && $method === 'POST') {
    Auth::logout();
    redirect('/');
}

if ($path === '/booru' && $method === 'GET') {
    $query = isset($_GET['q']) && trim((string) $_GET['q']) !== '' ? trim((string) $_GET['q']) : null;
    $page = max(1, (int) ($_GET['page'] ?? 1));

    $result = Post::search($page, $query);

    view('booru/gallery', [
        'title' => 'Gallery - TheKuz.win',
        'showHeader' => true,
        'posts' => $result['posts'],
        'totalCount' => $result['totalCount'],
        'page' => $result['page'],
        'totalPages' => $result['totalPages'],
        'query' => $query,
        'popularTags' => Post::popularTags(20),
    ]);
    exit;
}

if ($path === '/booru/upload') {
    if (!Auth::check()) {
        redirect('/auth/login');
    }

    if ($method === 'POST') {
        $meta = [
            'rating' => (string) ($_POST['rating'] ?? 'safe'),
            'category' => (string) ($_POST['category'] ?? 'gallery'),
            'source' => (string) ($_POST['source'] ?? ''),
            'description' => (string) ($_POST['description'] ?? ''),
        ];
        $result = Post::upload($_FILES['file'] ?? [], (string) ($_POST['tags'] ?? ''), Auth::user()['id'], $meta);

        if ($result['success']) {
            redirect('/post/view/' . $result['postId']);
        }

        view('booru/upload', [
            'title' => 'Upload - TheKuz.win',
            'showHeader' => true,
            'errors' => $result['errors'],
            'oldTags' => (string) ($_POST['tags'] ?? ''),
            'old' => $meta,
        ]);
        exit;
    }

    view('booru/upload', [
        'title' => 'Upload - TheKuz.win',
        'showHeader' => true,
        'errors' => [],
        'oldTags' => '',
        'old' => [],
    ]);
    exit;
}

if (preg_match('#^/post/view/(\d+)$#', $path, $m) && $method === 'GET') {
    $post = Post::find((int) $m[1]);
    if (!$post) {
        http_response_code(404);
        echo 'Post not found';
        exit;
    }

    $user = Auth::user();
    $reactions = Reaction::forEntity('post', $post['id'], $user['id'] ?? null);
    $comments = Comment::forPost($post['id']);
    $commentReactions = [];
    foreach ($comments as $c) {
        $commentReactions[$c['id']] = Reaction::forEntity('comment', (int) $c['id'], $user['id'] ?? null);
    }

    view('post/view', [
        'title' => 'Post #' . $post['id'] . ' - TheKuz.win',
        'showHeader' => true,
        'post' => $post,
        'reactions' => $reactions['reactions'],
        'userReactions' => $reactions['userReactions'],
        'canReact' => $user !== null,
        'isUploader' => $user !== null && $user['id'] === $post['uploader_id'],
        'voteState' => Post::voteState($post['id'], $user['id'] ?? null),
        'favoriteState' => Post::favoriteState($post['id'], $user['id'] ?? null),
        'user' => $user,
        'comments' => $comments,
        'commentReactions' => $commentReactions,
    ]);
    exit;
}

// AJAX: upvote/downvote/clear a vote on a post.
if (preg_match('#^/api/posts/(\d+)/vote$#', $path, $m) && $method === 'POST') {
    header('Content-Type: application/json');
    $user = Auth::user();
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'You must be logged in to vote.']);
        exit;
    }
    $postId = (int) $m[1];
    if (!Post::find($postId)) {
        http_response_code(404);
        echo json_encode(['error' => 'Post not found.']);
        exit;
    }
    $body = json_decode(file_get_contents('php://input') ?: '[]', true);
    $value = is_array($body) ? (int) ($body['value'] ?? 0) : 0;
    if (!in_array($value, [-1, 0, 1], true)) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid vote value.']);
        exit;
    }
    Post::vote($postId, $user['id'], $value);
    echo json_encode(Post::voteState($postId, $user['id']));
    exit;
}

// AJAX: toggle favorite on a post.
if (preg_match('#^/api/posts/(\d+)/favorite$#', $path, $m) && $method === 'POST') {
    header('Content-Type: application/json');
    $user = Auth::user();
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'You must be logged in to favorite.']);
        exit;
    }
    $postId = (int) $m[1];
    if (!Post::find($postId)) {
        http_response_code(404);
        echo json_encode(['error' => 'Post not found.']);
        exit;
    }
    echo json_encode(Post::toggleFavorite($postId, $user['id']));
    exit;
}

// Edit rating/category/source/description (uploader only). Plain POST + redirect
// back — no JS required, mirrors the "Save" button in the original sections.
if (preg_match('#^/post/(\d+)/update$#', $path, $m) && $method === 'POST') {
    $user = Auth::user();
    if (!$user) {
        redirect('/auth/login');
    }
    $postId = (int) $m[1];
    $field = (string) ($_POST['field'] ?? '');
    $value = (string) ($_POST['value'] ?? '');

    Post::updateField($postId, $user['id'], $field, $value);
    redirect('/post/view/' . $postId);
}

// AJAX: toggle an emote reaction on a post. Returns the updated reaction
// summary as JSON so the page can update without a full reload.
if (preg_match('#^/api/posts/(\d+)/reactions$#', $path, $m) && $method === 'POST') {
    header('Content-Type: application/json');

    $user = Auth::user();
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'You must be logged in to react.']);
        exit;
    }

    $postId = (int) $m[1];
    if (!Post::find($postId)) {
        http_response_code(404);
        echo json_encode(['error' => 'Post not found.']);
        exit;
    }

    $body = json_decode(file_get_contents('php://input') ?: '[]', true);
    $emoteName = is_array($body) ? (string) ($body['emoteName'] ?? '') : '';

    $result = Reaction::toggle('post', $postId, $user['id'], $emoteName);
    if (!$result['success']) {
        http_response_code(400);
        echo json_encode(['error' => $result['error']]);
        exit;
    }

    echo json_encode(Reaction::forEntity('post', $postId, $user['id']));
    exit;
}

// Post a new comment. Plain POST + redirect back to the post (with a
// #cN anchor), same as the rating/category/source/description forms —
// no JS required for the base case. ">>N" imageboard-style reply
// references are just part of the plain-text content — see
// Comment::linkify_reply_references().
if (preg_match('#^/post/(\d+)/comments$#', $path, $m) && $method === 'POST') {
    $user = Auth::user();
    if (!$user) {
        redirect('/auth/login');
    }
    $postId = (int) $m[1];
    $content = (string) ($_POST['content'] ?? '');

    $result = Comment::create($postId, $user['id'], $user['userName'], $content);
    if (!$result['success']) {
        redirect('/post/view/' . $postId . '?comment_error=' . urlencode($result['error']));
    }
    redirect('/post/view/' . $postId . '#c' . $result['comment']['id']);
}

// AJAX: edit a comment (owner only). Matches the original's inline
// edit UX — no full page reload.
if (preg_match('#^/api/comments/(\d+)$#', $path, $m) && $method === 'POST') {
    header('Content-Type: application/json');

    $user = Auth::user();
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'You must be logged in.']);
        exit;
    }

    $commentId = (int) $m[1];
    $body = json_decode(file_get_contents('php://input') ?: '[]', true);
    $content = is_array($body) ? (string) ($body['content'] ?? '') : '';

    $result = Comment::update($commentId, $user['id'], $content);
    if (!$result['success']) {
        http_response_code(400);
        echo json_encode(['error' => $result['error']]);
        exit;
    }

    $comment = $result['comment'];
    echo json_encode([
        'id' => (int) $comment['id'],
        'content' => $comment['content'],
        'contentHtml' => \Nuuru\Comment::linkify_reply_references(nl2br(e($comment['content']))),
        'editedAt' => $comment['edited_at'],
        'editedAtRelative' => relative_time($comment['edited_at']),
    ]);
    exit;
}

// AJAX: delete a comment (owner only — no moderator override yet, no
// permission system exists in this port).
if (preg_match('#^/api/comments/(\d+)/delete$#', $path, $m) && $method === 'POST') {
    header('Content-Type: application/json');

    $user = Auth::user();
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'You must be logged in.']);
        exit;
    }

    $commentId = (int) $m[1];
    $result = Comment::delete($commentId, $user['id']);
    if (!$result['success']) {
        http_response_code(400);
        echo json_encode(['error' => $result['error']]);
        exit;
    }

    echo json_encode(['success' => true]);
    exit;
}

// AJAX: toggle an emote reaction on a comment. Reuses the exact same
// generic Reaction system as posts (entity_type = 'comment').
if (preg_match('#^/api/comments/(\d+)/reactions$#', $path, $m) && $method === 'POST') {
    header('Content-Type: application/json');

    $user = Auth::user();
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'You must be logged in to react.']);
        exit;
    }

    $commentId = (int) $m[1];
    if (!Comment::find($commentId)) {
        http_response_code(404);
        echo json_encode(['error' => 'Comment not found.']);
        exit;
    }

    $body = json_decode(file_get_contents('php://input') ?: '[]', true);
    $emoteName = is_array($body) ? (string) ($body['emoteName'] ?? '') : '';

    $result = Reaction::toggle('comment', $commentId, $user['id'], $emoteName);
    if (!$result['success']) {
        http_response_code(400);
        echo json_encode(['error' => $result['error']]);
        exit;
    }

    echo json_encode(Reaction::forEntity('comment', $commentId, $user['id']));
    exit;
}

if (preg_match('#^/user/([^/]+)$#', $path, $m) && $method === 'GET') {
    $profile = UserProfile::findByUsername(urldecode($m[1]));
    if (!$profile) {
        http_response_code(404);
        echo 'User not found';
        exit;
    }

    $currentUser = Auth::user();
    $page = max(1, (int) ($_GET['page'] ?? 1));
    $result = Post::search($page, null, $profile['id']);

    view('user/profile', [
        'title' => $profile['user_name'] . ' - TheKuz.win',
        'showHeader' => true,
        'profile' => $profile,
        'stats' => UserProfile::stats($profile['id']),
        'isOwnProfile' => $currentUser !== null && $currentUser['id'] === $profile['id'],
        'posts' => $result['posts'],
        'page' => $result['page'],
        'totalPages' => $result['totalPages'],
        'currentUser' => $currentUser,
        'relationStatus' => $currentUser ? Relation::statusBetween($currentUser['id'], $profile['id']) : null,
        'friends' => Relation::friendsOf($profile['id']),
        'enemies' => Relation::enemiesOf($profile['id']),
    ]);
    exit;
}

if (preg_match('#^/user/([^/]+)/favorites$#', $path, $m) && $method === 'GET') {
    $profile = UserProfile::findByUsername(urldecode($m[1]));
    if (!$profile) {
        http_response_code(404);
        echo 'User not found';
        exit;
    }

    $page = max(1, (int) ($_GET['page'] ?? 1));
    $result = Post::searchFavoritedBy($profile['id'], $page);

    view('user/favorites', [
        'title' => $profile['user_name'] . "'s Favorites - TheKuz.win",
        'showHeader' => true,
        'profile' => $profile,
        'posts' => $result['posts'],
        'page' => $result['page'],
        'totalPages' => $result['totalPages'],
    ]);
    exit;
}

if (preg_match('#^/user/([^/]+)/relations$#', $path, $m) && $method === 'GET') {
    $profile = UserProfile::findByUsername(urldecode($m[1]));
    if (!$profile) {
        http_response_code(404);
        echo 'User not found';
        exit;
    }

    view('user/relations', [
        'title' => $profile['user_name'] . "'s Relations - TheKuz.win",
        'showHeader' => true,
        'username' => $profile['user_name'],
        'friends' => Relation::friendsOf($profile['id']),
        'enemies' => Relation::enemiesOf($profile['id']),
    ]);
    exit;
}

if (preg_match('#^/user/([^/]+)/(friend|unfriend|enemy|unenemy)$#', $path, $m) && $method === 'POST') {
    $user = Auth::user();
    if (!$user) {
        redirect('/auth/login');
    }
    $target = UserProfile::findByUsername(urldecode($m[1]));
    if (!$target) {
        http_response_code(404);
        echo 'User not found';
        exit;
    }

    $result = match ($m[2]) {
        'friend' => Relation::addFriend($user['id'], $target['id']),
        'unfriend' => Relation::removeFriend($user['id'], $target['id']),
        'enemy' => Relation::addEnemy($user['id'], $target['id']),
        'unenemy' => Relation::removeEnemy($user['id'], $target['id']),
    };

    $redirectUrl = '/user/' . rawurlencode($target['user_name']);
    if (!$result['success']) {
        $redirectUrl .= '?relation_error=' . urlencode($result['error']);
    }
    redirect($redirectUrl);
}

if ($path === '/notifications') {
    $user = Auth::user();
    if (!$user) {
        redirect('/auth/login');
    }
    $page = max(1, (int) ($_GET['page'] ?? 1));
    $result = Notification::forUser($user['id'], $page);

    view('notifications/index', [
        'title' => 'Notifications - TheKuz.win',
        'showHeader' => true,
        'notifications' => $result['notifications'],
        'unreadCount' => Notification::unreadCount($user['id']),
        'page' => $result['page'],
        'totalPages' => $result['totalPages'],
    ]);
    exit;
}

if (preg_match('#^/notifications/(\d+)/read$#', $path, $m) && $method === 'POST') {
    $user = Auth::user();
    if (!$user) {
        redirect('/auth/login');
    }
    Notification::markRead((int) $m[1], $user['id']);
    redirect('/notifications');
}

if (preg_match('#^/notifications/(\d+)/delete$#', $path, $m) && $method === 'POST') {
    $user = Auth::user();
    if (!$user) {
        redirect('/auth/login');
    }
    Notification::delete((int) $m[1], $user['id']);
    redirect('/notifications');
}

if ($path === '/notifications/read-all' && $method === 'POST') {
    $user = Auth::user();
    if (!$user) {
        redirect('/auth/login');
    }
    Notification::markAllRead($user['id']);
    redirect('/notifications');
}

if ($path === '/settings') {
    $user = Auth::user();
    if (!$user) {
        redirect('/auth/login');
    }
    $profile = UserProfile::findByUsername($user['userName']);

    view('settings/index', [
        'title' => 'Settings - TheKuz.win',
        'showHeader' => true,
        'profile' => $profile,
    ]);
    exit;
}

if ($path === '/settings/profile' && $method === 'POST') {
    $user = Auth::user();
    if (!$user) {
        redirect('/auth/login');
    }
    $result = UserProfile::updateProfile($user['id'], (string) ($_POST['status'] ?? ''), (string) ($_POST['biography'] ?? ''));
    $profile = UserProfile::findByUsername($user['userName']);

    view('settings/index', [
        'title' => 'Settings - TheKuz.win',
        'showHeader' => true,
        'profile' => $profile,
        'profileErrors' => $result['errors'],
        'successMessage' => $result['success'] ? 'Profile updated.' : null,
    ]);
    exit;
}

if ($path === '/settings/password' && $method === 'POST') {
    $user = Auth::user();
    if (!$user) {
        redirect('/auth/login');
    }
    $result = UserProfile::changePassword(
        $user['id'],
        (string) ($_POST['currentPassword'] ?? ''),
        (string) ($_POST['newPassword'] ?? ''),
        (string) ($_POST['confirmNewPassword'] ?? '')
    );
    $profile = UserProfile::findByUsername($user['userName']);

    view('settings/index', [
        'title' => 'Settings - TheKuz.win',
        'showHeader' => true,
        'profile' => $profile,
        'passwordErrors' => $result['errors'],
        'successMessage' => $result['success'] ? 'Password updated.' : null,
    ]);
    exit;
}

if ($path === '/settings/avatar' && $method === 'POST') {
    $user = Auth::user();
    if (!$user) {
        redirect('/auth/login');
    }
    $result = UserProfile::uploadAvatar($user['id'], $_FILES['avatar'] ?? []);
    $profile = UserProfile::findByUsername($user['userName']);

    view('settings/index', [
        'title' => 'Settings - TheKuz.win',
        'showHeader' => true,
        'profile' => $profile,
        'avatarErrors' => $result['errors'],
        'successMessage' => $result['success'] ? 'Avatar updated.' : null,
    ]);
    exit;
}

if ($path === '/settings/avatar/delete' && $method === 'POST') {
    $user = Auth::user();
    if (!$user) {
        redirect('/auth/login');
    }
    UserProfile::deleteAvatar($user['id']);
    redirect('/settings');
}

if ($path === '/settings/background' && $method === 'POST') {
    $user = Auth::user();
    if (!$user) {
        redirect('/auth/login');
    }
    $result = UserProfile::uploadBackgroundImage($user['id'], $_FILES['background'] ?? []);
    $profile = UserProfile::findByUsername($user['userName']);

    view('settings/index', [
        'title' => 'Settings - TheKuz.win',
        'showHeader' => true,
        'profile' => $profile,
        'backgroundErrors' => $result['errors'],
        'successMessage' => $result['success'] ? 'Background image updated.' : null,
    ]);
    exit;
}

if ($path === '/settings/background/delete' && $method === 'POST') {
    $user = Auth::user();
    if (!$user) {
        redirect('/auth/login');
    }
    UserProfile::deleteBackgroundImage($user['id']);
    redirect('/settings');
}

http_response_code(404);
echo '404 Not Found';
