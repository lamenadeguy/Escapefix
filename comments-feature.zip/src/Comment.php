<?php

declare(strict_types=1);

namespace Nuuru;

/**
 * Comments on posts, ported down from Nuuru.Server/Services/CommentService.cs
 * and Controllers/CommentController.cs.
 *
 * Simplifications vs the original (see README for the full list):
 * - Content is stored and displayed as plain text (nl2br(e(...)), same
 *   as post descriptions) instead of going through the BBCode ->
 *   ContentRaw/ContentHtml pipeline — there's no BBCode parser in this
 *   port yet, so there's no rich formatting, [thumb] embeds, or
 *   @mentions to extract.
 * - Reply references are imageboard-style ">>N" plain text (N = the
 *   id of the comment being replied to), not the original's
 *   [quote commentId=.. hash=..]content[/quote] BBCode block — see
 *   linkify_reply_references() below. Clicking a ">>N" jumps to
 *   #cN; there's no embedded copy of the quoted text, so if that
 *   comment is later deleted the reference just stops resolving
 *   (points at nothing) rather than showing a "quote unavailable"
 *   fallback — same tradeoff plain ">>N" imageboard replies make.
 * - No anonymous ("Chud") comments — that needs the permission system
 *   and captcha, neither of which exist here yet.
 * - No comment locking — that's a moderator/permission-gated feature
 *   on the original Post entity that doesn't exist in this schema.
 * - Delete is owner-only (the original also allows moderators with
 *   Permissions.Moderation.DeleteComment — no permission system here).
 * - No Boints credit, no auto-watch, no mention notifications, no
 *   live SignalR updates — those subsystems aren't ported yet.
 */
final class Comment
{
    public const MAX_LENGTH = 10000;

    /**
     * @return array{success: bool, error?: string, comment?: array<string, mixed>}
     */
    public static function create(int $postId, string $userId, string $userName, string $content): array
    {
        $content = trim($content);
        if ($content === '') {
            return ['success' => false, 'error' => 'Comment cannot be empty.'];
        }
        if (mb_strlen($content) > self::MAX_LENGTH) {
            return ['success' => false, 'error' => 'Comment is too long (max ' . self::MAX_LENGTH . ' characters).'];
        }

        $post = Post::find($postId);
        if (!$post) {
            return ['success' => false, 'error' => 'Post not found.'];
        }

        $pdo = Database::connection();
        $stmt = $pdo->prepare(
            'INSERT INTO comments (post_id, user_id, content) VALUES (:post_id, :user_id, :content)'
        );
        $stmt->execute(['post_id' => $postId, 'user_id' => $userId, 'content' => $content]);
        $commentId = (int) $pdo->lastInsertId();

        // Notify the post's uploader (unless they're commenting on their
        // own post) — 1:1 with CreateCommentNotificationAsync's message.
        if ($post['uploader_id'] !== $userId) {
            Notification::create(
                $post['uploader_id'],
                'comment',
                $userName . ' commented on your post',
                $userId,
                $postId
            );
        }

        return ['success' => true, 'comment' => self::find($commentId)];
    }

    /**
     * @return ?array<string, mixed>
     */
    public static function find(int $commentId): ?array
    {
        $stmt = Database::connection()->prepare(
            'SELECT comments.*, users.user_name AS author_name, users.avatar_url AS author_avatar_url
             FROM comments
             JOIN users ON users.id = comments.user_id
             WHERE comments.id = :id'
        );
        $stmt->execute(['id' => $commentId]);
        $row = $stmt->fetch();

        return $row === false ? null : $row;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function forPost(int $postId): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT comments.*, users.user_name AS author_name, users.avatar_url AS author_avatar_url
             FROM comments
             JOIN users ON users.id = comments.user_id
             WHERE comments.post_id = :post_id
             ORDER BY comments.created_at ASC, comments.id ASC'
        );
        $stmt->execute(['post_id' => $postId]);

        return $stmt->fetchAll();
    }

    public static function countForPost(int $postId): int
    {
        $stmt = Database::connection()->prepare('SELECT COUNT(*) FROM comments WHERE post_id = :post_id');
        $stmt->execute(['post_id' => $postId]);

        return (int) $stmt->fetchColumn();
    }

    /**
     * @return array{success: bool, error?: string, comment?: array<string, mixed>}
     */
    public static function update(int $commentId, string $userId, string $content): array
    {
        $comment = self::find($commentId);
        if (!$comment) {
            return ['success' => false, 'error' => 'Comment not found.'];
        }
        if ($comment['user_id'] !== $userId) {
            return ['success' => false, 'error' => 'You can only edit your own comments.'];
        }

        $content = trim($content);
        if ($content === '') {
            return ['success' => false, 'error' => 'Comment cannot be empty.'];
        }
        if (mb_strlen($content) > self::MAX_LENGTH) {
            return ['success' => false, 'error' => 'Comment is too long (max ' . self::MAX_LENGTH . ' characters).'];
        }

        $stmt = Database::connection()->prepare(
            "UPDATE comments SET content = :content, edited_at = datetime('now') WHERE id = :id"
        );
        $stmt->execute(['content' => $content, 'id' => $commentId]);

        return ['success' => true, 'comment' => self::find($commentId)];
    }

    /**
     * @return array{success: bool, error?: string}
     */
    public static function delete(int $commentId, string $userId): array
    {
        $comment = self::find($commentId);
        if (!$comment) {
            return ['success' => false, 'error' => 'Comment not found.'];
        }
        // Owner-only: the original also allows moderators with
        // Permissions.Moderation.DeleteComment, but there's no
        // permission system in this port yet.
        if ($comment['user_id'] !== $userId) {
            return ['success' => false, 'error' => 'You can only delete your own comments.'];
        }

        $stmt = Database::connection()->prepare('DELETE FROM comments WHERE id = :id');
        $stmt->execute(['id' => $commentId]);

        return ['success' => true];
    }

    /**
     * Turns imageboard-style ">>N" reply references into clickable
     * "#N" anchor links pointing at that comment (#cN), the way
     * every vichan/mitsuba-style imageboard renders them. Call this
     * on already-HTML-escaped, nl2br()'d content — it only touches
     * plain ">>123" text, so there's nothing to escape here.
     */
    public static function linkify_reply_references(string $escapedHtml): string
    {
        return preg_replace_callback(
            '/&gt;&gt;(\d+)/',
            static function (array $m): string {
                return '<a href="#c' . $m[1] . '" class="comment-reply-ref text-primary font-bold hover:underline" data-ref-id="' . $m[1] . '">&gt;&gt;' . $m[1] . '</a>';
            },
            $escapedHtml
        );
    }
}
