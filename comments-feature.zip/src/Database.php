<?php

declare(strict_types=1);

namespace Nuuru;

/**
 * Thin wrapper around a single PDO/SQLite connection.
 *
 * The original engine uses PostgreSQL/EF Core. For this early port we
 * keep everything in one .sqlite file so there's nothing to install or
 * configure — swap this class out later if/when a "real" DB is wired up.
 */
final class Database
{
    private static ?\PDO $pdo = null;

    public static function connection(): \PDO
    {
        if (self::$pdo === null) {
            $dbPath = dirname(__DIR__) . '/database/nuuru.sqlite';
            $isNew = !file_exists($dbPath);

            $pdo = new \PDO('sqlite:' . $dbPath);
            $pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);
            $pdo->exec('PRAGMA foreign_keys = ON');

            self::$pdo = $pdo;

            // Always (re-)apply the schema; CREATE TABLE IF NOT EXISTS makes
            // this safe to run on every request while the project is small.
            $schema = file_get_contents(dirname(__DIR__) . '/database/schema.sql');
            self::$pdo->exec($schema);

            self::migrate(self::$pdo);

            unset($isNew);
        }

        return self::$pdo;
    }

    /**
     * Tiny ad-hoc migration runner for columns added after a table already
     * existed — CREATE TABLE IF NOT EXISTS won't add new columns to a
     * table that's already there, so new nullable columns get patched in
     * here. Safe to run on every request (checks before altering).
     */
    private static function migrate(\PDO $pdo): void
    {
        $columns = $pdo->query('PRAGMA table_info(users)')->fetchAll();
        $columnNames = array_column($columns, 'name');

        if (!in_array('background_image_url', $columnNames, true)) {
            $pdo->exec('ALTER TABLE users ADD COLUMN background_image_url TEXT');
        }
    }
}
