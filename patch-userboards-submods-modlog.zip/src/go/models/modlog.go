package models

import (
	"time"
	"strconv"
	
	_ "3ch/backend/config"
	"3ch/backend/database"
	_ "3ch/backend/utils"
	
	"github.com/goodsign/monday"
)

type ModlogRecord struct {
	ID	int `gorm:"id" json:"id"`
	Moder	int `json:"moder"`
	ModerName	string `gorm:"-" json:"moder_name"`
	Action	string `json:"action"`
	ActionName	string `gorm:"-" json:"action_name"`
	ActionExplanation	string `gorm:"-" json:"action_explanation"`
	Board	string `json:"board"`
	Num	int `json:"num"`
	Parent	int `json:"parent"`
	Anywhere	int `json:"anywhere"`
	Delall	int `json:"delall"`
	NewBoard	string `json:"new_board"`
	Limit	int `json:"limit"`
	BanId	int `json:"ban_id"`
	IpOrSubnet	string `json:"ip_or_subnet"`
	IpSubnet	string `json:"ip_subnet"`
	Reason	string `json:"reason"`
	Ip	string `json:"ip"`
	Timestamp	int64 `json:"-"`
	End	int64 `json:"-"`
	Date	string `gorm:"-" json:"date"`
	DateEnd	string `gorm:"-" json:"date_end"`
	Post	ModerPost `gorm:"-" json:"post"`
}

type ModlogRecords []ModlogRecord

func (ModlogRecord) TableName() string {
	return "modlog"
}

func (record *ModlogRecord) ProcessVirtualFields() {
	record.Date = monday.Format(time.Unix(record.Timestamp, 0), "02/01/2006 Mon 15:04:05", "en_US")
	
	if(record.Action == "ban") {
		if(record.End > 0) {
			record.DateEnd = "until " + monday.Format(time.Unix(record.End, 0), "02/01/2006 Mon 15:04:05", "en_US")
		} else {
			record.DateEnd = "indefinitely"
		}
	}
	
	var moder Moder
	err := moder.GetById(record.Moder)
	
	if(err == nil) {
		record.ModerName = moder.Login
	}
	
	if(record.Action == "endless") {
		record.ActionExplanation = "enabled an endless thread with a limit of " + strconv.Itoa(record.Limit) + " posts"
	}
	
	if(record.Action == "finite") {
		record.ActionExplanation = "disabled the endless thread"
	}
	
	if(record.Action == "move") {
		record.ActionExplanation = "moved the thread"
	}
	
	if(record.Action == "close") {
		record.ActionExplanation = "closed the thread"
	}
	
	if(record.Action == "open") {
		record.ActionExplanation = "opened the thread"
	}
	
	if(record.Action == "pin") {
		record.ActionExplanation = "pinned the thread"
	}
	
	if(record.Action == "unpin") {
		record.ActionExplanation = "unpinned the thread"
	}
	
	if(record.Action == "restore") {
		record.ActionExplanation = "restored the post"
	}
	
	if(record.Action == "delete") {
		record.ActionExplanation = "deleted the post"
	}
	
	if(record.Action == "unban") {
		record.ActionExplanation = "cancelled the ban"
	}
	
	if(record.Action == "ban") {
		if(record.IpOrSubnet == "ip") {
			record.ActionExplanation = "banned the IP"
		} else {
			record.ActionExplanation = "banned the subnet"
		}
	}
}

func (records ModlogRecords) ProcessVirtualFields() {
	for i, record := range records {
		record.ProcessVirtualFields()
		records[i] = record
	}
}

func (record *ModlogRecord) Create() (error) {
	err := database.MySQL.Create(&record).Error
	
	if(err != nil) {
		return err
	}
	
	return nil
}

func (record *ModlogRecord) Update() (error) {
	err := database.MySQL.Save(&record).Error
	
	if(err != nil) {
		return err
	}
	
	return nil
}

func (record *ModlogRecord) GetById(id int) (error) {
	err := database.MySQL.First(&record, "`id` = ?", id).Error
	
	if(err != nil) {
		return err
	}
	
	return nil
}