package structs

import "3ch/backend/models"

type UserboardSubmodItem struct {
	ID       int
	Login    string
	Password string
	Hash     string
}

type UserboardSubmodsPage struct {
	Board   models.Board
	Submods []UserboardSubmodItem
}
