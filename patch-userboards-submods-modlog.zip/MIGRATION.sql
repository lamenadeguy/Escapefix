ALTER TABLE `moders` ADD COLUMN `is_userboard_mod` INT NOT NULL DEFAULT 0;
