<?php
const DBNAME = 'sharty';
const HOSTNAME = 'localhost';
const SQLUSERNAME = 'bansviewer';
const SQLPASS = 'Ziz(cWK^E!8BL6*EokjGge2ZDSDFA*r&';