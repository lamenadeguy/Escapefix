redis-cli flushall
