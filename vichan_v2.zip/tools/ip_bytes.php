<?php

require_once 'inc/bootstrap.php';

echo bytes_used_by_ip('5.70.143.92') / (1000*1000);
