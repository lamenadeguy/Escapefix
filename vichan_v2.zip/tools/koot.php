<?php

require_once 'inc/bootstrap.php';

echo $config['thumb_method'];
