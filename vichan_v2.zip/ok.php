<?php
require_once 'inc/bootstrap.php';

echo "OK";
?>
