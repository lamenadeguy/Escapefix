#!/bin/bash
# Копирует картинки/видео из /home/escapechan/root/<board>/{src,thumb}/...
# в /home/vichan/<board>/{src,thumb}/<new_name> по карте /root/media_copy_map.tsv
# (создаётся автоматически migrate.py)

set -e

OLD_ROOT="/home/escapechan/root"
NEW_ROOT="/home/vichan"
MAP="/root/media_copy_map.tsv"

if [ ! -f "$MAP" ]; then
  echo "Не найден $MAP — сначала запустите migrate.py"
  exit 1
fi

count=0
missing=0

while IFS=$'\t' read -r board old_src old_thumb new_src new_thumb; do
  mkdir -p "$NEW_ROOT/$board/src" "$NEW_ROOT/$board/thumb"

  src_from="$OLD_ROOT$old_src"
  thumb_from="$OLD_ROOT$old_thumb"

  if [ -f "$src_from" ]; then
    cp "$src_from" "$NEW_ROOT/$board/src/$new_src"
    count=$((count+1))
  else
    echo "НЕТ ФАЙЛА: $src_from"
    missing=$((missing+1))
  fi

  if [ -f "$thumb_from" ]; then
    cp "$thumb_from" "$NEW_ROOT/$board/thumb/$new_thumb"
  fi

done < "$MAP"

chown -R www-data:www-data "$NEW_ROOT"

echo "Скопировано файлов: $count"
echo "Отсутствовало в источнике: $missing"
