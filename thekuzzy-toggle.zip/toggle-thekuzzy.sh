#!/bin/bash
if [ "$1" == "live" ]; then
    ln -sf /etc/nginx/thekuzzy-mode-live.conf /etc/nginx/thekuzzy-mode.conf
    echo "thekuzzy.win -> LIVE site"
elif [ "$1" == "stub" ]; then
    ln -sf /etc/nginx/thekuzzy-mode-stub.conf /etc/nginx/thekuzzy-mode.conf
    echo "thekuzzy.win -> STUB (coming soon)"
else
    echo "Usage: $0 [live|stub]"
    exit 1
fi
nginx -t && systemctl reload nginx
