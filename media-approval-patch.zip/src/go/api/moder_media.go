package api

import (
	"os"
	"strconv"
	"net/http"
	"text/template"
	"encoding/json"
	"path/filepath"

	"github.com/gorilla/context"

	"3ch/backend/models"
	"3ch/backend/structs"
	"3ch/backend/database"
	"3ch/backend/i18n"
)

func ModerMediaList(w http.ResponseWriter, r *http.Request) {
	var moderPage structs.ModerPage
	moderPage.CurrentSection = "media"
	moderPage.Lang, _ = i18n.GetTranslations(os.Getenv("LANGUAGE"))
	moderPage.LangJson, _ = i18n.GetTranslationsJsonByPrefix(os.Getenv("LANGUAGE"), "moderation_")

	currentModer := context.Get(r, "currentModer").(models.Moder)
	moderPage.CurrentModer = currentModer

	var rows []struct {
		ID    int
		Board string
		Num   int
		Files string
	}

	database.MySQL.Raw("SELECT id, board, num, files FROM posts WHERE deleted = 0 AND files LIKE ? ORDER BY id DESC LIMIT 300", `%"approved":0%`).Scan(&rows)

	for _, row := range rows {
		var filesParsed models.Files
		json.Unmarshal([]byte(row.Files), &filesParsed)

		for i, f := range filesParsed {
			if f.Approved == 0 {
				moderPage.PendingMedia = append(moderPage.PendingMedia, structs.PendingMediaItem{
					PostID:           row.ID,
					Board:            row.Board,
					Num:              row.Num,
					FileIndex:        i,
					MD5:              f.MD5,
					Path:             f.Path,
					Thumbnail:        f.Thumbnail,
					OriginalFullName: f.OriginalFullName,
					Approved:         f.Approved,
				})
			}
		}
	}

	var processedRows []struct {
		ID    int
		Board string
		Num   int
		Files string
	}

	database.MySQL.Raw("SELECT id, board, num, files FROM posts WHERE deleted = 0 AND files LIKE ? AND files LIKE ? ORDER BY id DESC LIMIT 200", `%"approved_by"%`, `%"approved":%`).Scan(&processedRows)

	for _, row := range processedRows {
		var filesParsed models.Files
		json.Unmarshal([]byte(row.Files), &filesParsed)

		for i, f := range filesParsed {
			if f.ApprovedBy != "" && (f.Approved == 1 || f.Approved == 2) {
				moderPage.PendingMedia = append(moderPage.PendingMedia, structs.PendingMediaItem{
					PostID:           row.ID,
					Board:            row.Board,
					Num:              row.Num,
					FileIndex:        i,
					MD5:              f.MD5,
					Path:             f.Path,
					Thumbnail:        f.Thumbnail,
					OriginalFullName: f.OriginalFullName,
					Approved:         f.Approved,
					ApprovedBy:       f.ApprovedBy,
				})
			}
		}
	}

	ex, _ := os.Executable()
	exPath := filepath.Dir(ex)

	w.Header().Set("Content-Type", "text/html")

	tpls := make(map[string]*template.Template)
	tpls["top"] = template.Must(template.ParseFiles(exPath + "/templates/moder/top.html"))
	tpls["main"] = template.Must(template.ParseFiles(exPath + "/templates/moder/media.html"))
	tpls["bottom"] = template.Must(template.ParseFiles(exPath + "/templates/moder/bottom.html"))

	tpls["top"].ExecuteTemplate(w, "base", moderPage)
	tpls["main"].ExecuteTemplate(w, "base", moderPage)
	tpls["bottom"].ExecuteTemplate(w, "base", moderPage)
}

func ModerMediaAction(w http.ResponseWriter, r *http.Request) {
	currentModer := context.Get(r, "currentModer").(models.Moder)

	r.ParseForm()

	postId, _ := strconv.Atoi(r.FormValue("id"))
	fileIndex, _ := strconv.Atoi(r.FormValue("file_index"))
	action := r.FormValue("action")

	var post models.Post
	err := post.GetById(postId)

	if(err != nil) {
		http.Redirect(w, r, "/moder/media", http.StatusSeeOther)
		return
	}

	var filesParsed models.Files
	json.Unmarshal([]byte(post.Files), &filesParsed)

	if(fileIndex < 0 || fileIndex >= len(filesParsed)) {
		http.Redirect(w, r, "/moder/media", http.StatusSeeOther)
		return
	}

	targetFile := filesParsed[fileIndex]

	if(targetFile.Approved == 0) {
		os.Remove(os.Getenv("GENERATED_CACHE_DIRECTORY") + targetFile.Path)
		os.Remove(os.Getenv("GENERATED_CACHE_DIRECTORY") + targetFile.Thumbnail)

		if(action == "approve") {
			os.Symlink(targetFile.RealPath, os.Getenv("GENERATED_CACHE_DIRECTORY")+targetFile.Path)
			os.Symlink(targetFile.RealThumbnail, os.Getenv("GENERATED_CACHE_DIRECTORY")+targetFile.Thumbnail)

			targetFile.FullName = targetFile.OriginalFullName
			targetFile.DisplayName = targetFile.OriginalDisplayName
			targetFile.Approved = 1
			targetFile.ApprovedBy = currentModer.Login
		} else if(action == "reject") {
			os.Symlink(os.Getenv("GENERATED_CACHE_DIRECTORY")+"/static/img/eliminated_placeholder.jpg", os.Getenv("GENERATED_CACHE_DIRECTORY")+targetFile.Path)
			os.Symlink(os.Getenv("GENERATED_CACHE_DIRECTORY")+"/static/img/eliminated_placeholder.jpg", os.Getenv("GENERATED_CACHE_DIRECTORY")+targetFile.Thumbnail)

			os.Remove(targetFile.RealPath)
			os.Remove(targetFile.RealThumbnail)

			targetFile.FullName = "REDACTED BY ROSKOMNADZOR (ELIMINATED)"
			targetFile.DisplayName = "REDACTED BY ROSKOMNADZOR (ELIMINATED)"
			targetFile.Approved = 2
			targetFile.ApprovedBy = currentModer.Login
		}

		filesParsed[fileIndex] = targetFile

		updatedFilesJson, _ := json.Marshal(filesParsed)
		post.Files = string(updatedFilesJson)

		post.Update()
	}

	http.Redirect(w, r, "/moder/media", http.StatusSeeOther)
}
