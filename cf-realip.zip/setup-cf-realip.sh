#!/bin/bash
set -e

OUT=/etc/nginx/cloudflare-realip.conf

echo "# Auto-generated Cloudflare real IP config" > $OUT
echo "# Regenerate with this same script if Cloudflare's IP ranges change" >> $OUT
echo "" >> $OUT

for ip in $(curl -s https://www.cloudflare.com/ips-v4); do
    echo "set_real_ip_from $ip;" >> $OUT
done

for ip in $(curl -s https://www.cloudflare.com/ips-v6); do
    echo "set_real_ip_from $ip;" >> $OUT
done

echo "" >> $OUT
echo "real_ip_header CF-Connecting-IP;" >> $OUT

echo "Written to $OUT:"
cat $OUT
