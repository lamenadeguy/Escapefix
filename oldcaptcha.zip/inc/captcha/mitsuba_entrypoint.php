<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$store_dir = __DIR__ . '/../../tmp/captcha/';
if (!is_dir($store_dir)) {
    mkdir($store_dir, 0700, true);
}

function store_captcha($store_dir, $cookie, $target, $positions) {
    $path = $store_dir . preg_replace('/[^a-f0-9]/', '', $cookie) . '.json';
    file_put_contents($path, json_encode(['target' => $target, 'positions' => $positions, 'ts' => time()]));
}

function fetch_captcha($store_dir, $cookie) {
    $path = $store_dir . preg_replace('/[^a-f0-9]/', '', $cookie) . '.json';
    if (!file_exists($path)) return null;
    $data = json_decode(file_get_contents($path), true);
    unlink($path);
    return $data;
}

function cleanup_captcha($store_dir) {
    if (mt_rand(0, 50) !== 0) return;
    foreach (glob($store_dir . '*.json') as $f) {
        $data = json_decode(file_get_contents($f), true);
        if ($data && time() - $data['ts'] > 300) unlink($f);
    }
}

/**
 * Verify a mitsuba captcha directly without an HTTP round-trip.
 *
 * @param string $store_dir  Path to the captcha storage directory.
 * @param string $cookie     The captcha cookie/token.
 * @param string $text       The user's text answer.
 * @param float|null $click_x User's click X coordinate.
 * @param float|null $click_y User's click Y coordinate.
 * @return bool True if the captcha is solved correctly.
 */
function mitsuba_check_direct($store_dir, $cookie, $text, $click_x, $click_y) {
    $data = fetch_captcha($store_dir, $cookie);
    if (!$data) return false;
    if (time() - $data['ts'] > 300) return false;
    if (strtolower($data['target']) !== strtolower(trim($text))) return false;
    if ($click_x === null || $click_y === null || $click_x < 0 || $click_y < 0) return false;

    $margin = 18;
    foreach ($data['positions'] as $p) {
        if (strtolower($p['group']) !== strtolower($data['target'])) continue;
        $cx = $p['x'] + $p['w'] / 2;
        $cy = $p['y'] + $p['h'] / 2;
        $hw = $p['w'] / 2 + $margin;
        $hh = $p['h'] / 2 + $margin;
        $dx = $click_x - $cx;
        $dy = $click_y - $cy;
        $cos = cos(-$p['angle']);
        $sin = sin(-$p['angle']);
        $lx = $dx * $cos - $dy * $sin;
        $ly = $dx * $sin + $dy * $cos;
        if (abs($lx) <= $hw && abs($ly) <= $hh) return true;
    }
    return false;
}

// HTTP entrypoint — only runs when called directly via web.
if (!defined('TINYBOARD')) {
    header('Content-Type: application/json');
    $mode = $_GET['mode'] ?? '';
    if ($mode !== 'get' && $mode !== 'check') {
        echo json_encode(['error' => 'unknown mode']);
        exit;
    }
}

if (!defined('TINYBOARD') && $mode === 'get') {
    $dir = __DIR__ . '/../../static/captcha/';
    $raw = [];

    if (is_dir($dir)) {
        foreach (scandir($dir) as $f) {
            if (preg_match('/\.(png|jpg|jpeg|gif|webp)$/i', $f)) {
                $base = pathinfo($f, PATHINFO_FILENAME);
                $ext  = strtolower(pathinfo($f, PATHINFO_EXTENSION));
                $group = trim(rtrim($base, '0123456789'));
                if ($group === '') $group = $base;
                $raw[] = ['file' => $base, 'ext' => $ext, 'group' => $group];
            }
        }
    }

    if (count($raw) < 3) {
        echo json_encode(['error' => 'Not enough captcha images in /static/captcha/']);
        exit;
    }

    $groups = [];
    foreach ($raw as $item) {
        $groups[$item['group']][] = $item;
    }

    $groupKeys = array_keys($groups);
    shuffle($groupKeys);
    $count = min(rand(4, 5), count($groupKeys));
    $selectedGroups = array_slice($groupKeys, 0, $count);

    $selected = [];
    foreach ($selectedGroups as $g) {
        $variants = $groups[$g];
        $item = $variants[array_rand($variants)];
        $selected[] = ['file' => $item['file'], 'ext' => $item['ext'], 'group' => $g];
    }

    $targetIdx = array_rand($selected);
    $target = $selected[$targetIdx]['group'];

    $W = 420; $H = 260; $BAND = 38; $minSide = 26; $maxSide = 46; $pad = 10;
    $cols = count($selected) <= 4 ? 4 : 3;
    $rows = (int)ceil(count($selected) / $cols);
    $cellW = $W / $cols;
    $cellH = ($H - $BAND) / $rows;

    $cells = [];
    for ($r = 0; $r < $rows; $r++)
        for ($c = 0; $c < $cols; $c++)
            $cells[] = ['cx' => $c, 'cy' => $r];
    shuffle($cells);

    $srv_positions = [];
    foreach ($selected as $i => $item) {
        $w = mt_rand($minSide, $maxSide);
        $h = mt_rand($minSide, $maxSide);
        $cell = $cells[$i % count($cells)];
        $maxOffX = max(0, $cellW - $w - $pad * 2);
        $maxOffY = max(0, $cellH - $h - $pad * 2);
        $x = $cell['cx'] * $cellW + $pad + ($maxOffX > 0 ? mt_rand(0, (int)($maxOffX * 100)) / 100 : 0);
        $y = $BAND + $cell['cy'] * $cellH + $pad + ($maxOffY > 0 ? mt_rand(0, (int)($maxOffY * 100)) / 100 : 0);
        $angle = (mt_rand(-900, 900)) / 1000.0;
        $srv_positions[] = [
            'group' => $item['group'],
            'x'     => round($x, 2),
            'y'     => round($y, 2),
            'w'     => $w,
            'h'     => $h,
            'angle' => $angle,
            'file'  => $item['file'],
            'ext'   => $item['ext'],
        ];
    }

    $cookie = bin2hex(random_bytes(16));

    cleanup_captcha($store_dir);
    store_captcha($store_dir, $cookie, $target, $srv_positions);

    $bg_dots = [];
    for ($i = 0; $i < 200; $i++) {
        $bg_dots[] = [round(mt_rand(0, $W * 100) / 100, 2), round(mt_rand(0, $H * 100) / 100, 2), round(mt_rand(2, 7) / 100, 3)];
    }
    $bg_lines = [];
    for ($i = 0; $i < 12; $i++) {
        $bg_lines[] = [
            round(mt_rand(0, $W * 100) / 100, 2), round(mt_rand(0, $H * 100) / 100, 2),
            round(mt_rand(0, $W * 100) / 100, 2), round(mt_rand(0, $H * 100) / 100, 2),
            round(mt_rand(0, $W * 100) / 100, 2), round(mt_rand(0, $H * 100) / 100, 2),
            round(mt_rand(0, $W * 100) / 100, 2), round(mt_rand(0, $H * 100) / 100, 2),
            round(mt_rand(4, 16) / 100, 3),
        ];
    }

    $obj_noise = [];
    foreach ($srv_positions as $p) {
        $dots = [];
        for ($i = 0; $i < 35; $i++) {
            $dots[] = [round(mt_rand(0, $p['w'] * 100) / 100, 2), round(mt_rand(0, $p['h'] * 100) / 100, 2), mt_rand(0, 1), round(mt_rand(4, 22) / 100, 3)];
        }
        $scratches = [];
        for ($i = 0; $i < 3; $i++) {
            $scratches[] = [
                round(mt_rand(0, $p['w'] * 100) / 100, 2), round(mt_rand(0, $p['h'] * 100) / 100, 2),
                round(mt_rand(0, $p['w'] * 100) / 100, 2), round(mt_rand(0, $p['h'] * 100) / 100, 2),
                round(mt_rand(5, 20) / 100, 3),
            ];
        }
        $obj_noise[] = ['dots' => $dots, 'scratches' => $scratches];
    }

    $label = 'Click on "' . $target . '"';
    $letters = [];
    $len = mb_strlen($label, 'utf-8');
    for ($i = 0; $i < $len; $i++) {
        $letters[] = [
            mb_substr($label, $i, 1, 'utf-8'),
            round(mt_rand(-700, 700) / 100, 2),
            round(mt_rand(-55, 55) / 100, 3),
            mt_rand(13, 23),
            round(mt_rand(-400, 200) / 100, 2),
        ];
    }
    $text_dots = [];
    for ($i = 0; $i < 260; $i++) {
        $text_dots[] = [round(mt_rand(0, $W * 100) / 100, 2), round(mt_rand(0, $BAND * 100) / 100, 2), mt_rand(0, 1), round(mt_rand(15, 45) / 100, 3), mt_rand(1, 3)];
    }
    $text_scratches = [];
    $scratchCount = mt_rand(4, 6);
    for ($i = 0; $i < $scratchCount; $i++) {
        $y1 = round(mt_rand(0, (int)($BAND * 100)) / 100, 2);
        $y2 = round(mt_rand(0, (int)($BAND * 100)) / 100, 2);
        $text_scratches[] = [
            round(mt_rand(0, (int)($W * 0.15 * 100)) / 100, 2), $y1,
            round(mt_rand((int)($W * 0.85 * 100), $W * 100) / 100, 2), $y2,
            round(mt_rand(180, 320) / 100, 2),
        ];
    }

    $images_json = json_encode($selected, JSON_HEX_APOS | JSON_HEX_QUOT);
    $positions_json = json_encode(array_map(function($p) {
        return ['x' => $p['x'], 'y' => $p['y'], 'w' => $p['w'], 'h' => $p['h'], 'angle' => $p['angle'], 'file' => $p['file'], 'ext' => $p['ext'], 'group' => $p['group']];
    }, $srv_positions), JSON_HEX_APOS | JSON_HEX_QUOT);
    $obj_noise_json = json_encode($obj_noise, JSON_HEX_APOS | JSON_HEX_QUOT);
    $bg_dots_json = json_encode($bg_dots, JSON_HEX_APOS | JSON_HEX_QUOT);
    $bg_lines_json = json_encode($bg_lines, JSON_HEX_APOS | JSON_HEX_QUOT);
    $letters_json = json_encode($letters, JSON_HEX_APOS | JSON_HEX_QUOT);
    $text_dots_json = json_encode($text_dots, JSON_HEX_APOS | JSON_HEX_QUOT);
    $text_scratches_json = json_encode($text_scratches, JSON_HEX_APOS | JSON_HEX_QUOT);

    $provider_url = htmlspecialchars($_SERVER['PHP_SELF'] ?? $_SERVER['SCRIPT_NAME'] ?? '', ENT_QUOTES);
    $html = '<div id="mitsuba-cap-wrap" data-provider="'.$provider_url.'">';
    $html .= '<canvas id="mitsuba-cap-canvas" width="420" height="260" style="display:block;cursor:crosshair;border:1px solid #aaa;max-width:100%;"></canvas>';
    $html .= '</div>';
    $html .= '<script>(function(){';
    $html .= "var FIXED_POSITIONS={$positions_json};";
    $html .= "var OBJ_NOISE={$obj_noise_json};";
    $html .= "var BG_DOTS={$bg_dots_json};";
    $html .= "var BG_LINES={$bg_lines_json};";
    $html .= "var LETTERS={$letters_json};";
    $html .= "var TEXT_DOTS={$text_dots_json};";
    $html .= "var TEXT_SCRATCHES={$text_scratches_json};";
    $html .= 'var PROVIDER=(document.getElementById("mitsuba-cap-wrap")||{}).getAttribute("data-provider")||"";';
    $html .= 'setTimeout(function(){';
    $html .= 'var W=420,H=260,BAND=38,positions=[],clickX=null,clickY=null;';
    $html .= 'var canvas=document.getElementById("mitsuba-cap-canvas");';
    $html .= 'if(!canvas)return;';
    $html .= 'var ctx=canvas.getContext("2d");';
    $html .= 'function redraw(){';
    $html .= 'ctx.fillStyle="#f0e0d6";ctx.fillRect(0,0,W,H);';
    $html .= 'BG_DOTS.forEach(function(d){ctx.fillStyle="rgba(0,0,0,"+d[2]+")";ctx.fillRect(d[0],d[1],1.5,1.5);});';
    $html .= 'ctx.strokeStyle="rgba(0,0,0,0.05)";ctx.lineWidth=1;';
    $html .= 'for(var g=0;g<W;g+=20){ctx.beginPath();for(var yy=0;yy<H;yy+=4){var xx=g+Math.sin(yy*0.1)*3;yy===0?ctx.moveTo(xx,yy):ctx.lineTo(xx,yy);}ctx.stroke();}';
    $html .= 'positions.forEach(function(p,pi){';
    $html .= 'ctx.save();ctx.translate(p.x+p.w/2,p.y+p.h/2);ctx.rotate(p.angle);ctx.drawImage(p.img,-p.w/2,-p.h/2,p.w,p.h);';
    $html .= 'var hw=p.w/2,hh=p.h/2;var noise=OBJ_NOISE[pi];';
    $html .= 'if(noise){noise.dots.forEach(function(d){ctx.fillStyle="rgba("+(d[2]?"255,255,255,":"0,0,0,")+d[3]+")";ctx.fillRect(-hw+d[0],-hh+d[1],1.8,1.8);});';
    $html .= 'noise.scratches.forEach(function(s){ctx.strokeStyle="rgba(0,0,0,"+s[4]+")";ctx.lineWidth=0.8;ctx.beginPath();ctx.moveTo(-hw+s[0],-hh+s[1]);ctx.lineTo(-hw+s[2],-hh+s[3]);ctx.stroke();});}';
    $html .= 'ctx.restore();});';
    $html .= 'BG_LINES.forEach(function(l){ctx.strokeStyle="rgba(0,0,0,"+l[8]+")";ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(l[0],l[1]);ctx.bezierCurveTo(l[2],l[3],l[4],l[5],l[6],l[7]);ctx.stroke();});';
    $html .= 'if(clickX!==null&&clickY!==null){ctx.save();ctx.strokeStyle="rgba(200,0,0,0.85)";ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(clickX,0);ctx.lineTo(clickX,H);ctx.stroke();ctx.beginPath();ctx.moveTo(0,clickY);ctx.lineTo(W,clickY);ctx.stroke();ctx.restore();}';
    $html .= 'ctx.fillStyle="rgba(0,0,0,0.75)";ctx.fillRect(0,0,W,BAND);';
    $html .= 'ctx.textBaseline="middle";ctx.fillStyle="white";';
    $html .= 'var tx=8,ty=BAND/2;';
    $html .= 'LETTERS.forEach(function(lt){';
    $html .= 'ctx.save();';
    $html .= 'ctx.font="bold "+lt[3]+"px monospace";';
    $html .= 'var cw=ctx.measureText(lt[0]).width;';
    $html .= 'tx+=lt[4];';
    $html .= 'ctx.translate(tx+cw/2,ty+lt[1]);';
    $html .= 'ctx.rotate(lt[2]);';
    $html .= 'ctx.fillText(lt[0],-cw/2,0);';
    $html .= 'ctx.restore();';
    $html .= 'tx+=cw;';
    $html .= '});';
    $html .= 'TEXT_DOTS.forEach(function(d){ctx.fillStyle="rgba("+(d[2]?"255,255,255,":"0,0,0,")+d[3]+")";ctx.fillRect(d[0],d[1],d[4],d[4]);});';
    $html .= 'TEXT_SCRATCHES.forEach(function(s){ctx.strokeStyle="rgba(0,0,0,"+s[4]/100+")";ctx.lineWidth=1.6;ctx.beginPath();ctx.moveTo(s[0],s[1]);ctx.lineTo(s[2],s[3]);ctx.stroke();});';
    $html .= '}';
    $html .= 'function loadImages(){';
    $html .= 'var done=0;';
    $html .= 'FIXED_POSITIONS.forEach(function(fp){';
    $html .= 'var img=new Image();';
    $html .= 'img.onload=function(){positions.push({img:img,x:fp.x,y:fp.y,w:fp.w,h:fp.h,angle:fp.angle,group:fp.group});done++;if(done===FIXED_POSITIONS.length)redraw();};';
    $html .= 'img.onerror=function(){done++;if(done===FIXED_POSITIONS.length)redraw();};';
    $html .= 'img.src="/static/captcha/"+encodeURIComponent(fp.file)+"."+fp.ext;';
    $html .= '});}';
    $html .= 'canvas.addEventListener("click",function(e){';
    $html .= 'e.stopPropagation();';
    $html .= 'var rect=canvas.getBoundingClientRect();';
    $html .= 'var scaleX=W/rect.width,scaleY=H/rect.height;';
    $html .= 'clickX=(e.clientX-rect.left)*scaleX;clickY=(e.clientY-rect.top)*scaleY;';
    $html .= 'var td=$(canvas).closest("td");';
    $html .= 'td.find(".captcha_click_x").val(Math.round(clickX));';
    $html .= 'td.find(".captcha_click_y").val(Math.round(clickY));';
    $html .= 'redraw();});';
    $html .= 'loadImages();},0);})();</script>';

    echo json_encode([
        'cookie'      => $cookie,
        'captchahtml' => $html,
        'expires_in'  => 300,
    ]);
    exit;
}

if (!defined('TINYBOARD') && $mode === 'check') {
    $req = array_merge($_GET, $_POST);
    $cookie = preg_replace('/[^a-f0-9]/', '', $req['cookie'] ?? '');
    $answer = strtolower(trim($req['text'] ?? ''));

    $data = fetch_captcha($store_dir, $cookie);

    if (!$data) { echo '0'; exit; }
    if (time() - $data['ts'] > 300) { echo '0'; exit; }

    if (strtolower($data['target']) !== $answer) { echo '0'; exit; }

    $click_x = null;
    $click_y = null;
    if (isset($req['click_x']) && is_numeric($req['click_x'])) {
        $click_x = (float)$req['click_x'];
    }
    if (isset($req['click_y']) && is_numeric($req['click_y'])) {
        $click_y = (float)$req['click_y'];
    }

    if ($click_x === null || $click_y === null || $click_x < 0 || $click_y < 0) { echo '0'; exit; }

    $hit = false;
    $margin = 18;
    foreach ($data['positions'] as $p) {
        if (strtolower($p['group']) !== strtolower($data['target'])) continue;
        $cx = $p['x'] + $p['w'] / 2;
        $cy = $p['y'] + $p['h'] / 2;
        $hw = $p['w'] / 2 + $margin;
        $hh = $p['h'] / 2 + $margin;
        $dx = $click_x - $cx;
        $dy = $click_y - $cy;
        $cos = cos(-$p['angle']);
        $sin = sin(-$p['angle']);
        $lx = $dx * $cos - $dy * $sin;
        $ly = $dx * $sin + $dy * $cos;
        if (abs($lx) <= $hw && abs($ly) <= $hh) { $hit = true; break; }
    }

    echo $hit ? '1' : '0';
    exit;
}
