CREATE TABLE IF NOT EXISTS `banners` (
  `id` int NOT NULL AUTO_INCREMENT,
  `board` varchar(20) NOT NULL DEFAULT '',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(500) NOT NULL DEFAULT '',
  `timestamp` bigint NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `board` (`board`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
