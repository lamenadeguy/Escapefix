package api

import (
	"os"
	"image"
	"image/jpeg"
	"image/draw"
	_ "image/png"
	_ "image/gif"
	_ "golang.org/x/image/webp"
	"math"
	"strconv"
	"strings"
	"net/http"
	"text/template"
	"encoding/json"
	"path/filepath"

	"github.com/gorilla/mux"
	"github.com/gorilla/context"
	"github.com/nfnt/resize"
	"github.com/thanhpk/randstr"

	"3ch/backend/models"
	"3ch/backend/structs"
	"3ch/backend/database"
	"3ch/backend/i18n"
)

const bannerWidth = 300
const bannerHeight = 100

// Scales the image up (never down below target) so it fully covers a
// bannerWidth x bannerHeight box, then crops the centered excess -- so the
// output is *always* exactly 300x100, regardless of the source image's
// original size or aspect ratio.
func resizeBannerCover(img image.Image) image.Image {
	bounds := img.Bounds()
	srcW := bounds.Dx()
	srcH := bounds.Dy()

	if(srcW == 0 || srcH == 0) {
		return image.NewRGBA(image.Rect(0, 0, bannerWidth, bannerHeight))
	}

	scaleW := float64(bannerWidth) / float64(srcW)
	scaleH := float64(bannerHeight) / float64(srcH)

	scale := scaleW
	if(scaleH > scale) {
		scale = scaleH
	}

	newW := uint(math.Ceil(float64(srcW) * scale))
	newH := uint(math.Ceil(float64(srcH) * scale))

	if(newW < bannerWidth) {
		newW = bannerWidth
	}

	if(newH < bannerHeight) {
		newH = bannerHeight
	}

	resized := resize.Resize(newW, newH, img, resize.Lanczos3)

	offsetX := (int(newW) - bannerWidth) / 2
	offsetY := (int(newH) - bannerHeight) / 2

	canvas := image.NewRGBA(image.Rect(0, 0, bannerWidth, bannerHeight))
	draw.Draw(canvas, canvas.Bounds(), resized, image.Point{offsetX, offsetY}, draw.Src)

	return canvas
}

func ModerBannersList(w http.ResponseWriter, r *http.Request) {
	var moderPage structs.ModerPage
	moderPage.CurrentSection = "banners"
	moderPage.Lang, _ = i18n.GetTranslations(os.Getenv("LANGUAGE"))
	moderPage.LangJson, _ = i18n.GetTranslationsJsonByPrefix(os.Getenv("LANGUAGE"), "moderation_")

	currentModer := context.Get(r, "currentModer").(models.Moder)

	if(currentModer.Level < 4) {
		http.Redirect(w, r, "/moder/posts", http.StatusSeeOther)
		return
	}

	moderPage.CurrentModer = currentModer

	var boards models.Boards

	database.MySQL.Order("id asc").Find(&boards)

	moderPage.Boards = boards
	moderPage.Banners = models.GetAllBanners()

	ex, _ := os.Executable()
	exPath := filepath.Dir(ex)

	w.Header().Set("Content-Type", "text/html")

	tpls := make(map[string]*template.Template)
	tpls["top"] = template.Must(template.ParseFiles(exPath + "/templates/moder/top.html"))
	tpls["main"] = template.Must(template.ParseFiles(exPath + "/templates/moder/moders_banners.html"))
	tpls["bottom"] = template.Must(template.ParseFiles(exPath + "/templates/moder/bottom.html"))

	tpls["top"].ExecuteTemplate(w, "base", moderPage)
	tpls["main"].ExecuteTemplate(w, "base", moderPage)
	tpls["bottom"].ExecuteTemplate(w, "base", moderPage)
}

func ModerBannersUpload(w http.ResponseWriter, r *http.Request) {
	currentModer := context.Get(r, "currentModer").(models.Moder)

	if(currentModer.Level < 4) {
		http.Redirect(w, r, "/moder/posts", http.StatusSeeOther)
		return
	}

	err := r.ParseMultipartForm(20 << 20) // 20MB

	if(err != nil) {
		http.Redirect(w, r, "/moder/banners", http.StatusSeeOther)
		return
	}

	file, _, err := r.FormFile("banner")

	if(err != nil) {
		http.Redirect(w, r, "/moder/banners", http.StatusSeeOther)
		return
	}

	defer file.Close()

	img, _, err := image.Decode(file)

	if(err != nil) {
		http.Redirect(w, r, "/moder/banners", http.StatusSeeOther)
		return
	}

	resizedImg := resizeBannerCover(img)

	filename := randstr.Hex(16) + ".jpg"

	bannersDir := os.Getenv("GENERATED_CACHE_DIRECTORY") + "/static/banners"

	os.MkdirAll(bannersDir, 0777)

	outFile, err := os.Create(bannersDir + "/" + filename)

	if(err != nil) {
		http.Redirect(w, r, "/moder/banners", http.StatusSeeOther)
		return
	}

	defer outFile.Close()

	jpeg.Encode(outFile, resizedImg, &jpeg.Options{Quality: 90})

	board := strings.TrimSpace(r.FormValue("board"))
	link := strings.TrimSpace(r.FormValue("link"))

	if(board == "all") {
		board = ""
	}

	banner := models.Banner{
		Board:    board,
		Filename: filename,
		Link:     link,
	}

	banner.Create()

	http.Redirect(w, r, "/moder/banners", http.StatusSeeOther)
}

func ModerBannersDelete(w http.ResponseWriter, r *http.Request) {
	currentModer := context.Get(r, "currentModer").(models.Moder)

	if(currentModer.Level < 4) {
		http.Redirect(w, r, "/moder/posts", http.StatusSeeOther)
		return
	}

	id, _ := strconv.Atoi(r.FormValue("id"))

	var banner models.Banner

	err := banner.GetById(id)

	if(err == nil && banner.ID > 0) {
		os.Remove(os.Getenv("GENERATED_CACHE_DIRECTORY") + "/static/banners/" + banner.Filename)
		banner.Delete()
	}

	http.Redirect(w, r, "/moder/banners", http.StatusSeeOther)
}

// Public endpoint used by the board pages to fetch a random banner (global
// or board-specific) client-side, on every page view.
func GetRandomBanner(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	vars := mux.Vars(r)
	board := strings.TrimSpace(vars["board"])

	banner, err := models.GetRandomBannerForBoard(board)

	var response struct {
		Filename string `json:"filename"`
		Link     string `json:"link"`
	}

	if(err == nil && banner.ID > 0) {
		response.Filename = banner.Filename
		response.Link = banner.Link
	}

	jsonResponse, _ := json.MarshalIndent(response, "", "    ")
	w.Write(jsonResponse)
}
