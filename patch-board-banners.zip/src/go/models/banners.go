package models

import (
	"time"

	"3ch/backend/database"
)

type Banner struct {
	ID        int    `gorm:"column:id" json:"id"`
	Board     string `gorm:"column:board" json:"board"` // "" == shown on every board
	Filename  string `gorm:"column:filename" json:"filename"`
	Link      string `gorm:"column:link" json:"link"`
	Timestamp int64  `gorm:"column:timestamp" json:"timestamp"`
}

func (Banner) TableName() string {
	return "banners"
}

func (banner *Banner) Create() error {
	banner.Timestamp = time.Now().Unix()
	return database.MySQL.Create(&banner).Error
}

func (banner *Banner) GetById(id int) error {
	return database.MySQL.First(&banner, "id = ?", id).Error
}

func (banner *Banner) Delete() error {
	return database.MySQL.Delete(&banner).Error
}

type Banners []Banner

func GetAllBanners() Banners {
	var rows Banners
	database.MySQL.Order("id desc").Find(&rows)
	return rows
}

// Picks one random banner available for the given board: either scoped
// specifically to that board, or a global one (board == "").
func GetRandomBannerForBoard(board string) (Banner, error) {
	var banner Banner
	err := database.MySQL.Where("board = ? OR board = ''", board).Order("RAND()").Limit(1).First(&banner).Error
	return banner, err
}
