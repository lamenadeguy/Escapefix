ALTER TABLE media_approvals ADD COLUMN original_type INT DEFAULT 1;
