package models

import (
	"time"

	"3ch/backend/database"
)

type MediaApproval struct {
	ID                  int    `gorm:"id"`
	Board               string `gorm:"board"`
	Num                 int    `gorm:"num"`
	FileIndex           int    `gorm:"file_index"`
	MD5                 string `gorm:"md5"`
	Status              int    `gorm:"status"`
	PublicPath          string `gorm:"public_path"`
	PublicThumbnail     string `gorm:"public_thumbnail"`
	RealPath            string `gorm:"real_path"`
	RealThumbnail       string `gorm:"real_thumbnail"`
	OriginalFullName    string `gorm:"original_fullname"`
	OriginalDisplayName string `gorm:"original_displayname"`
	ApprovedBy          string `gorm:"approved_by"`
	CreatedAt           int64  `gorm:"created_at"`
}

func (MediaApproval) TableName() string {
	return "media_approvals"
}

func (m *MediaApproval) Create() error {
	m.CreatedAt = time.Now().Unix()
	err := database.MySQL.Create(&m).Error
	return err
}

func (m *MediaApproval) GetById(id int) error {
	return database.MySQL.First(&m, "id = ?", id).Error
}

func (m *MediaApproval) Update() error {
	return database.MySQL.Save(&m).Error
}

type MediaApprovals []MediaApproval

func GetPendingMediaApprovals() MediaApprovals {
	var rows MediaApprovals
	database.MySQL.Where("status = 0").Order("id desc").Limit(300).Find(&rows)
	return rows
}

func GetProcessedMediaApprovals() MediaApprovals {
	var rows MediaApprovals
	database.MySQL.Where("status != 0").Order("id desc").Limit(200).Find(&rows)
	return rows
}
