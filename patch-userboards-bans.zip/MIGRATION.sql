UPDATE `moders` SET `is_userboard_mod` = 1 WHERE `login` LIKE 'userboard_%' OR `login` LIKE 'ubsub_%';
