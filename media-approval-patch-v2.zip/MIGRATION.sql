CREATE TABLE IF NOT EXISTS media_approvals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  board VARCHAR(50) NOT NULL,
  num INT NOT NULL,
  file_index INT NOT NULL,
  md5 VARCHAR(64),
  status TINYINT NOT NULL DEFAULT 0,
  public_path TEXT,
  public_thumbnail TEXT,
  real_path TEXT,
  real_thumbnail TEXT,
  original_fullname TEXT,
  original_displayname TEXT,
  approved_by VARCHAR(64) DEFAULT '',
  created_at BIGINT,
  INDEX (board, num),
  INDEX (status)
);
