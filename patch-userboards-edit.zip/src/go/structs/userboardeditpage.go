package structs

import "3ch/backend/models"

type UserboardEditPage struct {
	Board     models.Board
	ErrorText string
}
