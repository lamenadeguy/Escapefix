package api

import (
	"os"
	"log"
	"errors"
	"time"
	"strings"
	"strconv"
	"net/http"
	"text/template"
	"encoding/json"
	"path/filepath"

	"github.com/thanhpk/randstr"

	"3ch/backend/models"
	"3ch/backend/structs"
	"3ch/backend/database"
)

const maxUserboards = 3
const userboardsCategoryId = 8 // "Юзерборды" -- see config.GetCategories()

// Resolves the passcode currently logged in via the passcode_auth cookie
// (the same cookie/session used for captcha-free posting).
func getCurrentPasscode(r *http.Request) (models.Passcode, bool) {
	var passcode models.Passcode

	cookie, err := r.Cookie("passcode_auth")

	if(err != nil) {
		return passcode, false
	}

	err = passcode.GetBySession(cookie.Value)

	if(err != nil || passcode.ID == 0) {
		return passcode, false
	}

	if(passcode.Banned > 0 || passcode.Expires < time.Now().Unix()) {
		return passcode, false
	}

	return passcode, true
}

func userboardModerLogin(passcodeId int) string {
	return "userboard_" + strconv.Itoa(passcodeId)
}

// Grants (or extends) the passcode owner's restricted moderator account:
// level 1 (delete/ban by IP, hashed IPs, reports), scoped only to the
// boards they themselves created via /userboards.
func grantUserboardModeration(passcode models.Passcode, boardId string) {
	login := userboardModerLogin(passcode.ID)

	var moder models.Moder
	err := moder.GetByLogin(login)

	newPermission := models.ModerPermission{Board: boardId, Thread: ""}

	if(err != nil) {
		permissions := models.ModerPermissions{newPermission}
		permissionsJson, _ := json.Marshal(permissions)

		moder = models.Moder{
			Login:       login,
			Password:    randstr.Hex(24),
			Note:        "Auto-created userboard owner account (passcode #" + strconv.Itoa(passcode.ID) + ")",
			Permissions: string(permissionsJson),
			Level:       1,
			Enabled:     1,
			Timestamp:   time.Now().Unix(),
		}

		moder.Create()
	} else {
		var permissions models.ModerPermissions
		json.Unmarshal([]byte(moder.Permissions), &permissions)

		alreadyHasIt := false

		for _, permission := range permissions {
			if(permission.Board == boardId) {
				alreadyHasIt = true
				break
			}
		}

		if(!alreadyHasIt) {
			permissions = append(permissions, newPermission)

			permissionsJson, _ := json.Marshal(permissions)
			moder.Permissions = string(permissionsJson)
			moder.Update()
		}
	}
}

func createUserboard(passcode models.Passcode, r *http.Request) (string, error) {
	var count int64
	database.MySQL.Model(&models.Board{}).Where("owner_passcode_id = ?", passcode.ID).Count(&count)

	if(count >= maxUserboards) {
		return "You already have the maximum of " + strconv.Itoa(maxUserboards) + " boards.", errors.New("limit reached")
	}

	boardId := strings.ToLower(strings.TrimSpace(r.FormValue("board_id")))
	name := strings.TrimSpace(r.FormValue("board_name"))
	info := strings.TrimSpace(r.FormValue("board_info"))

	if(boardId == "" || !IsAlNum(boardId)) {
		return "Board ID can only contain latin letters and digits.", errors.New("invalid id")
	}

	if(len(boardId) > 10) {
		return "Board ID is too long (max 10 characters).", errors.New("invalid id")
	}

	if(name == "") {
		return "Specify a board name.", errors.New("invalid name")
	}

	var existing models.Board
	err := existing.GetById(boardId)

	if(err == nil) {
		return "This board ID is already taken.", errors.New("taken")
	}

	board := models.Board{
		ID:              boardId,
		Name:            name,
		Info:            info,
		DefaultName:     "Anonymous",
		CategoryId:      userboardsCategoryId,
		OwnerPasscodeId: passcode.ID,
		EnablePosting:   1,
		EnableSubject:   1,
		EnableNames:     1,
		EnableTrips:     1,
		EnableSage:      1,
		EnableOpMod:     1,
		MaxComment:      15000,
		MaxFilesSize:    20 * 1024,
		BumpLimit:       500,
		MaxPages:        10,
		ThreadsPerPage:  20,
		Threads:         200,
		BanReasons:      "[]",
		Spamlist:        "[]",
	}

	err = board.Create()

	if(err != nil) {
		log.Println("userboards: board.Create() failed:", err)
		return "Failed to create the board, please try again.", err
	}

	grantUserboardModeration(passcode, boardId)

	return "", nil
}

func UserboardsPageHandler(w http.ResponseWriter, r *http.Request) {
	var page structs.UserboardsPage
	page.MaxBoards = maxUserboards

	method := r.Method

	if(method == "POST" && r.FormValue("action") == "login") {
		code := strings.TrimSpace(r.FormValue("passcode"))

		var passcode models.Passcode
		var sessions []string

		err := passcode.GetByCode(code)

		if(err != nil) {
			page.AuthFailed = 1
			page.ErrorText = "Passcode not found."
		} else if(passcode.Expires < time.Now().Unix()) {
			page.AuthFailed = 1
			page.ErrorText = "Passcode expired."
		} else if(passcode.Banned > 0) {
			page.AuthFailed = 1
			page.ErrorText = "This passcode is banned."
		} else {
			_ = json.Unmarshal([]byte(passcode.Sessions), &sessions)

			session := randstr.Hex(16)
			sessions = append(sessions, session)

			if(len(sessions) > 100) {
				sessions = sessions[1:]
			}

			updatedSessionsJson, _ := json.Marshal(sessions)
			passcode.Sessions = string(updatedSessionsJson)
			passcode.Update()

			passcodeCookie := &http.Cookie{Name: "passcode_auth", Value: session, Path: "/", HttpOnly: false}
			http.SetCookie(w, passcodeCookie)

			http.Redirect(w, r, "/userboards", http.StatusSeeOther)
			return
		}
	}

	passcode, loggedIn := getCurrentPasscode(r)
	page.LoggedIn = loggedIn

	if(loggedIn) {
		if(method == "POST" && r.FormValue("action") == "create") {
			createError, err := createUserboard(passcode, r)

			if(err == nil) {
				http.Redirect(w, r, "/userboards", http.StatusSeeOther)
				return
			}

			page.CreateError = createError
		}

		database.MySQL.Where("owner_passcode_id = ?", passcode.ID).Order("id asc").Find(&page.Boards)
	}

	ex, _ := os.Executable()
	exPath := filepath.Dir(ex)

	w.Header().Set("Content-Type", "text/html")

	tpls := template.Must(template.ParseFiles(exPath + "/templates/userboards.html"))
	tpls.ExecuteTemplate(w, "base", page)
}

// Logs the passcode owner straight into the existing /moder panel, using
// their auto-provisioned, board-scoped moderator account. No separate
// moderation UI needed -- it's the same panel, just permission-limited.
func UserboardsModerate(w http.ResponseWriter, r *http.Request) {
	passcode, loggedIn := getCurrentPasscode(r)

	if(!loggedIn) {
		http.Redirect(w, r, "/userboards", http.StatusSeeOther)
		return
	}

	boardId := strings.TrimSpace(r.URL.Query().Get("board"))

	var board models.Board
	err := board.GetById(boardId)

	if(err != nil || board.OwnerPasscodeId != passcode.ID) {
		http.Redirect(w, r, "/userboards", http.StatusSeeOther)
		return
	}

	var moder models.Moder
	err = moder.GetByLogin(userboardModerLogin(passcode.ID))

	if(err != nil) {
		http.Redirect(w, r, "/userboards", http.StatusSeeOther)
		return
	}

	var sessions []string
	_ = json.Unmarshal([]byte(moder.Sessions), &sessions)

	session := randstr.Hex(16)
	sessions = append(sessions, session)

	if(len(sessions) > 100) {
		sessions = sessions[1:]
	}

	updatedSessionsJson, _ := json.Marshal(sessions)
	moder.Sessions = string(updatedSessionsJson)
	moder.Update()

	moderCookie := &http.Cookie{Name: "moder", Value: session, Path: "/", HttpOnly: false}
	http.SetCookie(w, moderCookie)

	http.Redirect(w, r, "/moder/posts", http.StatusSeeOther)
}
